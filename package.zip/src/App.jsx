import { useState } from "react";
import Login from "./Login";
import Courses from "./Courses";
import Watch from "./Watch";
import Layout from "./Layout";
import CoursePage from "./CoursePage";
import Admin from "./Admin";
import AdminDashboard from "./AdminDashboard";
import StudentLayout from "./StudentLayout";
import Register from "./Register";
import AdminStudents from "./AdminStudents";
import StudentDashboard from "./StudentDashboard";
import AdminUnits from "./AdminUnits";
import VideoPlayer from "./BunnyStream/VideoPlayer";


import { getUser } from "./auth";
import AdminLayout from "./AdminLayout";




export default function App() {
  const user = getUser();

  const [logged, setLogged] = useState(
    !!localStorage.getItem("token")
  );

  const path = window.location.pathname;
  let page = null;

  // Public routes first
  if (path === "/login") {
    page = <Login onLogin={() => setLogged(true)} />;
  }
  else if (path === "/register") {
    page = <Register />;
  } else if (path.startsWith("/dashboard")) {
    if (!logged) {
      page = <Login onLogin={() => setLogged(true)} />;
    } else {
      page = (
        <StudentLayout>
          <StudentDashboard />
        </StudentLayout>
      );
    }
  }

  else if (path === "/admin") {
    if (!logged || user?.role !== "ADMIN") {
      page = <Login onLogin={() => setLogged(true)} />;
    } else {
      // page = <Admin />;
      page = <AdminLayout />;
    }
  }
  else if (path.startsWith("/course/")) {
    const id = path.split("/")[2];
    page = <CoursePage id={id} />;
  }
  else if (path.startsWith("/watch/")) {
    const id = path.split("/watch/")[1];
    page = <Watch courseId={id} />;
  }
  else if (path === "/admin") {
    // Protect ONLY admin route
    if (!logged) page = <Login onLogin={() => setLogged(true)} />;
    else page = <Admin />;
    // else page = <AdminDashboard />;
  } else if (path === "/admin/students") {
    page = <AdminStudents />;
  }
  else if (path.startsWith("/admin/course/")) {
    if (!user || user.role !== "ADMIN") {
      page = <Login />;
    } else {
      const courseId = path.split("/admin/course/")[1];
      page = <AdminUnits courseId={courseId} />;
    }
  }
  else {
    page = <Courses />;
    // page = <VideoPlayer />;
  }

  return <Layout>{page}</Layout>;
}
