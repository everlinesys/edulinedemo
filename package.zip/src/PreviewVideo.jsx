import { useBranding } from "./useBranding";
import VideoPlayer from "./BunnyStream/VideoPlayer";

export default function PreviewVideo() {
  const brand = useBranding();
  const theme = brand.theme || {};

  const preview = brand.preview || {};
  const perks = preview.perks || [
    { value: "HD", label: "High Definition" },
    { value: "24/7", label: "Lifetime Access" },
  ];

  // 👇 PRIORITY LOGIC
  const videoId =
    preview.bunnyVideoId ||
    brand.hero?.bunnyVideoId;

  const poster =
    preview.poster ||
    brand.hero?.poster;

  return (
    <section
      className={`
        relative overflow-hidden
        ${theme.layout?.panel || ""}
        ${theme.shape?.radius || ""}
        shadow-2xl
      `}
    >
      {/* Glow */}
      <div
        className="absolute top-0 right-0 w-96 h-96 blur-[100px] -mr-48 -mt-48"
        style={{ backgroundColor: brand.colors.primary + "22" }}
      />

      <div className="relative z-10 grid lg:grid-cols-2 gap-0 items-center">

        {/* TEXT */}
        <div className="p-6 md:p-10 lg:p-14 space-y-6 md:space-y-8">
          <h2 className={`text-3xl md:text-5xl ${theme.text?.title || ""}`}>
            {preview.title}
            <span style={{ color: brand.colors.primary }}>
              {preview.highlight}
            </span>
          </h2>

          <p className={`text-sm md:text-base ${theme.text?.body}`}>
            {preview.description}
          </p>
        </div>

        {/* ================= FIXED VIDEO SECTION ================= */}
        <div className="w-full h-[420px] sm:h-[520px] md:h-[560px] lg:h-[600px] relative">

          <div className="
            absolute inset-0
            flex items-center justify-center
            bg-black
          ">
            <VideoPlayer
              videoId={videoId}
              poster={poster}
            />
          </div>

        </div>
        {/* ======================================================== */}

      </div>
    </section>
  );
}
