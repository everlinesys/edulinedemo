import { useState } from "react";
import api from "./api";
import { useBranding } from "./useBranding";

export default function Login({ onLogin }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const brand = useBranding();
  const theme = brand.theme;

  async function submit(e) {
    e.preventDefault();

    try {
      const res = await api.post("/auth/login", { email, password });

      localStorage.setItem("token", res.data.token);

      if (onLogin) onLogin();

      const user = res.data.user;
      console.log("LOGIN RESPONSE:", res.data);

      if (user.role === "ADMIN") {
        window.location = "/admin";
      } else {
        window.location = "/dashboard";
      }
    } catch (err) {
      console.error("LOGIN ERROR:", err);
      alert("Invalid credentials");
    }
  }

  return (
    <section
      className={`
        min-h-screen flex items-center justify-center
        ${theme.layout.container}
      `}
      style={{ "--color-primary": brand.colors.primary }}
    >
      {/* CARD */}
      <form
        className={`
          w-full max-w-sm
          p-6 md:p-8 space-y-5
          shadow-2xl
          ${theme.layout.panel}
          ${theme.shape.radius}
        `}
        onSubmit={submit}
      >
        {/* TITLE */}
        <h2 className={`text-2xl ${theme.text.title}`}>
          Login
        </h2>

        {/* EMAIL */}
        <input
          className={`
            w-full px-3 py-2 text-sm
            ${theme.input.base}
            ${theme.shape.inputRadius}
          `}
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />

        {/* PASSWORD */}
        <input
          type="password"
          className={`
            w-full px-3 py-2 text-sm
            ${theme.input.base}
            ${theme.shape.inputRadius}
          `}
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        {/* SUBMIT */}
        <button
          type="submit"
          className={`
            w-full py-2.5 text-sm font-bold transition-all
            ${theme.button.primary}
            ${theme.shape.buttonRadius}
          `}
        >
          Login
        </button>

        {/* REGISTER LINK */}
        <div className={`text-sm text-center ${theme.text.body}`}>
          Don’t have an account?{" "}
          <a
            href="/register"
            className="underline font-semibold"
            style={{ color: "var(--color-primary)" }}
          >
            Sign up
          </a>
        </div>

      </form>
    </section>
  );
}
