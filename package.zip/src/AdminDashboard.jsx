import React, { useState } from 'react';
import { 
  Users, 
  BookOpen, 
  DollarSign, 
  TrendingUp, 
  Clock, 
  CheckCircle,
  BarChart3,
  Layers,
  Search,
  Bell
} from 'lucide-react';

const StatCard = ({ title, value, change, icon: Icon, color }) => (
  <div className="bg-slate-900/50 border border-slate-800 p-6 rounded-[2rem] backdrop-blur-sm hover:border-indigo-500/50 transition-all group">
    <div className="flex justify-between items-start mb-4">
      <div className={`p-3 rounded-2xl ${color} bg-opacity-10 text-opacity-100`}>
        <Icon size={24} className={color.replace('bg-', 'text-')} />
      </div>
      <span className={`text-xs font-bold px-2 py-1 rounded-lg bg-emerald-500/10 text-emerald-500`}>
        {change}
      </span>
    </div>
    <h3 className="text-slate-500 text-xs font-black uppercase tracking-widest">{title}</h3>
    <p className="text-3xl font-bold text-white mt-1 tracking-tight">{value}</p>
  </div>
);

// Mock Graph Component (Visual Placeholder)
const MockGraph = () => (
  <div className="relative h-48 w-full flex items-end gap-2 px-2">
    {[40, 70, 45, 90, 65, 80, 95, 60, 85, 40, 75, 50].map((h, i) => (
      <div key={i} className="flex-1 group relative">
        <div 
          className="w-full bg-indigo-500/20 rounded-t-lg group-hover:bg-indigo-500 transition-all duration-500" 
          style={{ height: `${h}%` }}
        ></div>
        <div className="absolute -top-8 left-1/2 -translate-x-1/2 bg-white text-black text-[10px] font-bold px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity">
          {h}%
        </div>
      </div>
    ))}
  </div>
);

export default function AdminDashboard() {
  const [search, setSearch] = useState("");

  return (
    <div className="min-h-screen bg-slate-950 text-white p-6 lg:p-10 font-sans">
      {/* HEADER */}
      <header className="max-w-7xl mx-auto flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-3xl font-black tracking-tighter">Command Center</h1>
          <p className="text-slate-500 text-sm font-medium">Welcome back, Admin. Here is your platform overview.</p>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
            <input 
              type="text"
              placeholder="Search courses or users..."
              className="bg-slate-900 border border-slate-800 rounded-2xl py-3 pl-12 pr-6 text-sm outline-none focus:border-indigo-500 transition-all w-64"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          <button className="p-3 bg-slate-900 border border-slate-800 rounded-2xl text-slate-400 hover:text-white transition-all">
            <Bell size={20} />
          </button>
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 border-2 border-slate-800" />
        </div>
      </header>

      <main className="max-w-7xl mx-auto space-y-8">
        
        {/* TOP STATS GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard title="Total Students" value="12,842" change="+14%" icon={Users} color="bg-indigo-500" />
          <StatCard title="Course Sales" value="$42,390" change="+8.2%" icon={DollarSign} color="bg-emerald-500" />
          <StatCard title="Active Courses" value="156" change="+2" icon={BookOpen} color="bg-amber-500" />
          <StatCard title="Completion Rate" value="78.4%" change="+5.1%" icon={CheckCircle} color="bg-rose-500" />
        </div>

        {/* ANALYTICS BENTO SECTION */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Chart */}
          <div className="lg:col-span-2 bg-slate-900/40 border border-slate-800 rounded-[2.5rem] p-8">
            <div className="flex justify-between items-center mb-10">
              <div>
                <h3 className="text-xl font-bold">Engagement Trends</h3>
                <p className="text-slate-500 text-xs">Daily active minutes across all units</p>
              </div>
              <select className="bg-slate-950 border border-slate-800 text-xs font-bold rounded-xl px-4 py-2 outline-none">
                <option>Last 30 Days</option>
                <option>Last 6 Months</option>
              </select>
            </div>
            <MockGraph />
            <div className="flex justify-between mt-6 px-2">
              {['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(m => (
                <span key={m} className="text-[10px] font-bold text-slate-600 uppercase tracking-tighter">{m}</span>
              ))}
            </div>
          </div>

          {/* Quick Actions Sidebar */}
          <div className="space-y-6">
            <div className="bg-indigo-600 rounded-[2.5rem] p-8 relative overflow-hidden group">
              <TrendingUp className="absolute -right-4 -bottom-4 text-indigo-400/20" size={160} />
              <h3 className="text-xl font-bold mb-2">Pro Insights</h3>
              <p className="text-indigo-100/70 text-sm mb-6">Your "React Advanced" course is trending. Consider adding a final assessment.</p>
              <button className="bg-white text-indigo-600 px-6 py-3 rounded-2xl text-xs font-black uppercase tracking-widest hover:bg-slate-100 transition-all">
                View Report
              </button>
            </div>

            <div className="bg-slate-900/40 border border-slate-800 rounded-[2.5rem] p-8">
              <h3 className="font-bold mb-6">Recent Enrolments</h3>
              <div className="space-y-4">
                {[
                  { name: "Alex Rivera", course: "UI Design Masterclass", time: "2m ago" },
                  { name: "Sarah Chen", course: "Advanced Node.js", time: "15m ago" },
                  { name: "M. Richards", course: "BunnyStream Basics", time: "1h ago" }
                ].map((user, i) => (
                  <div key={i} className="flex items-center gap-4 border-b border-slate-800/50 pb-4 last:border-0 last:pb-0">
                    <div className="w-10 h-10 rounded-xl bg-slate-800 flex-shrink-0" />
                    <div className="flex-1">
                      <p className="text-sm font-bold truncate">{user.name}</p>
                      <p className="text-[10px] text-slate-500">{user.course}</p>
                    </div>
                    <span className="text-[10px] text-slate-600 font-medium">{user.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>

        {/* COURSE PERFORMANCE TABLE */}
        <section className="bg-slate-900/40 border border-slate-800 rounded-[2.5rem] overflow-hidden">
          <div className="p-8 border-b border-slate-800 flex justify-between items-center">
            <h3 className="text-xl font-bold">Course Performance</h3>
            <button className="text-indigo-500 text-xs font-bold uppercase tracking-widest hover:text-white transition-colors">View All</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="text-slate-500 text-[10px] font-black uppercase tracking-[0.2em] bg-slate-900/20">
                  <th className="px-8 py-4">Course Name</th>
                  <th className="px-8 py-4">Units</th>
                  <th className="px-8 py-4">Students</th>
                  <th className="px-8 py-4">Rating</th>
                  <th className="px-8 py-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {[
                  { name: "Mastering React 19", units: 12, students: "1,204", rating: "4.9", status: "Published" },
                  { name: "Fullstack SaaS Kit", units: 24, students: "850", rating: "4.8", status: "Published" },
                  { name: "Cybersecurity 101", units: 8, students: "2,100", rating: "4.7", status: "Draft" },
                ].map((row, i) => (
                  <tr key={i} className="hover:bg-slate-800/30 transition-colors group">
                    <td className="px-8 py-5 text-sm font-bold text-slate-200">{row.name}</td>
                    <td className="px-8 py-5 text-sm text-slate-400">{row.units} Chapters</td>
                    <td className="px-8 py-5 text-sm text-slate-400">{row.students}</td>
                    <td className="px-8 py-5 text-sm">
                      <div className="flex items-center gap-1 text-amber-500 font-bold">★ {row.rating}</div>
                    </td>
                    <td className="px-8 py-5">
                      <span className={`text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-tighter ${
                        row.status === 'Published' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'
                      }`}>
                        {row.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    </div>
  );
}