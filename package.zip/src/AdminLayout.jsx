import React, { useState, useEffect } from "react";
import api from "./api";
import {
  LayoutDashboard,
  BookOpen,
  Users,
  MousePointer2,
  ShieldCheck,
  Settings,
  History,
  HardDrive,
  TrendingUp,
  Menu,
  X,
} from "lucide-react";

import CourseEditor from "./AdminCourseEditor";

const AdminLayout = () => {

  const [open, setOpen] = useState(false);
  const [revenue, setRevenue] = useState(null);

  // ===== SIMPLE PAGE ROUTING =====
  const [page, setPage] = useState("dashboard");

  useEffect(() => {
    async function load() {
      try {
        const res = await api.get("/admin/stats/revenue");
        setRevenue(res.data.total);
      } catch {
        setRevenue(0);
      }
    }
    load();
  }, []);

  function formatMoney(v) {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(v || 0);
  }

  // ===== RIGHT SIDE RENDER =====
  function renderPage() {
    switch (page) {

      case "courses":
        return <CourseEditor />;

      case "students":
        return <div>Students management coming...</div>;

      case "visitors":
        return <div>Visitors analytics coming...</div>;

      case "security":
        return <div>Security settings coming...</div>;

      case "access":
        return <div>Access management coming...</div>;

      case "history":
        return <div>Login history coming...</div>;

      case "storage":
        return <div>Storage manager coming...</div>;

      case "sales":
        return <div>Total sales report coming...</div>;

      default:
        return (
          <div>
            <h1 className="text-2xl font-bold mb-4">
              Admin Dashboard
            </h1>

            <div className="bg-white p-6 rounded-xl border">
              Welcome to admin panel
            </div>
          </div>
        );
    }
  }

  return (
    <div className="flex bg-[#f1f1f1] font-sans text-[#303030]">

      {/* ===== MOBILE BACKDROP ===== */}
      {open && (
        <div
          className="fixed inset-0 bg-black/40 z-30 md:hidden"
          onClick={() => setOpen(false)}
        />
      )}

      {/* ===== SIDEBAR ===== */}
      <aside
        className={`
          fixed md:static z-40 top-0 left-0 h-full
          w-64 bg-[#ebebeb] border-r border-[#d2d2d2]
          flex flex-col transition-transform duration-200

          ${open ? "translate-x-0" : "-translate-x-full"}
          md:translate-x-0
        `}
      >

        {/* MOBILE HEADER */}
        <div className="md:hidden flex items-center justify-between p-3 border-b bg-white">
          <span className="font-bold">Admin Menu</span>

          <button onClick={() => setOpen(false)}>
            <X size={20} />
          </button>
        </div>

        {/* ===== NAVIGATION ===== */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-1">

          <button
            onClick={() => setPage("dashboard")}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-[#e1e1e1] rounded"
          >
            <LayoutDashboard size={18} />
            Dashboard
          </button>

          <button
            onClick={() => setPage("courses")}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-[#e1e1e1] rounded"
          >
            <BookOpen size={18} />
            Courses
          </button>

          <button
            onClick={() => setPage("students")}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-[#e1e1e1] rounded"
          >
            <Users size={18} />
            Students
          </button>

          <button
            onClick={() => setPage("visitors")}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-[#e1e1e1] rounded"
          >
            <MousePointer2 size={18} />
            Visitors
          </button>

          <button
            onClick={() => setPage("security")}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-[#e1e1e1] rounded"
          >
            <ShieldCheck size={18} />
            Security
          </button>

          <button
            onClick={() => setPage("access")}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-[#e1e1e1] rounded"
          >
            <Settings size={18} />
            Access Management
          </button>

          <button
            onClick={() => setPage("history")}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-[#e1e1e1] rounded"
          >
            <History size={18} />
            Login History
          </button>

          <button
            onClick={() => setPage("storage")}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-[#e1e1e1] rounded"
          >
            <HardDrive size={18} />
            Storage
          </button>

          <button
            onClick={() => setPage("sales")}
            className="w-full flex items-center gap-3 px-3 py-2 hover:bg-[#e1e1e1] rounded"
          >
            <TrendingUp size={18} />
            Total Sales
          </button>

        </nav>

        {/* ===== BOTTOM REVENUE ===== */}
        <div className="p-4 border-t bg-white fixed bottom-0 left-0 w-64 md:static">
          <p className="text-xs">Total Revenue</p>

          <p className="font-bold text-indigo-700">
            {formatMoney(revenue)}
          </p>
        </div>

      </aside>

      {/* ===== MAIN ===== */}
      <main className="flex-1 flex flex-col">

        {/* MOBILE TOP BAR */}
        <div className="md:hidden p-3 border-b bg-white">
          <button onClick={() => setOpen(true)}>
            <Menu size={20} />
          </button>
        </div>

        <section className="flex-1 p-6 bg-[#f6f6f7]">
          {renderPage()}
        </section>

      </main>

    </div>
  );
};

export default AdminLayout;
