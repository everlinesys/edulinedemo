import { useEffect, useState } from "react";
import api from "./api";

const IconPlus = () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>;
const IconTrash = () => <svg xmlns="http://www.w3.org/2000/svg" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18m-2 0v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6m3 0V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>;

export default function AdminFinalTest({ courseId }) {
  const [tests, setTests] = useState([]);
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", "", "", ""]);
  const [answerIndex, setAnswerIndex] = useState(null);

  async function load() {
    const res = await api.get(`/final-test/admin/${courseId}`);
    setTests(res.data);
  }

  useEffect(() => { load(); }, [courseId]);

  const updateOption = (i, val) => {
    const updated = [...options];
    updated[i] = val;
    setOptions(updated);
  };

  async function addQuestion(e) {
    e.preventDefault();
    if (!question || answerIndex === null) return;
    const cleanOptions = options.filter(o => o.trim());
    const answer = cleanOptions[answerIndex];
    await api.post("/final-test", {
      courseId, title: "Final Course Test", question,
      options: JSON.stringify(cleanOptions), answer
    });
    setQuestion(""); setOptions(["", "", "", ""]); setAnswerIndex(null);
    load();
  }

  async function removeQuestion(id) {
    if (!window.confirm("Delete?")) return;
    await api.delete(`/final-test/${id}`);
    load();
  }

  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
      {/* COMPACT HEADER */}
      <div className="bg-slate-50 border-b border-slate-100 px-4 py-2 flex justify-between items-center">
        <h2 className="text-[11px] font-black uppercase tracking-widest text-slate-500 flex items-center gap-2">
          <span className="text-base">🎓</span> Final Assessment Builder
        </h2>
        <span className="text-[10px] font-bold text-slate-400">{tests.length} Questions</span>
      </div>

      <div className="p-4 space-y-6">
        {/* ADD QUESTION - HIGH DENSITY FORM */}
        <form onSubmit={addQuestion} className="bg-slate-50/50 border border-slate-200 rounded-lg p-3 space-y-3">
          <input
            className="w-full bg-white border border-slate-200 p-2 rounded text-xs font-semibold outline-none focus:border-slate-400"
            placeholder="Question text..."
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />

          <div className="grid grid-cols-2 gap-2">
            {options.map((opt, i) => (
              <div key={i} className={`flex items-center gap-2 border rounded px-2 py-1 transition-colors ${answerIndex === i ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200'}`}>
                <input
                  type="radio"
                  name="correct"
                  className="w-3 h-3 accent-emerald-600"
                  checked={answerIndex === i}
                  onChange={() => setAnswerIndex(i)}
                />
                <input
                  className="flex-1 bg-transparent outline-none text-[11px]"
                  placeholder={`Option ${i + 1}`}
                  value={opt}
                  onChange={(e) => updateOption(i, e.target.value)}
                />
              </div>
            ))}
          </div>

          <button className="w-full bg-slate-900 text-white py-1.5 rounded text-[11px] font-bold flex items-center justify-center gap-2 hover:bg-black transition-all">
            <IconPlus /> Save Question to Bank
          </button>
        </form>

        {/* QUESTIONS LIST - TWO COLUMN GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {tests.map((t, i) => {
            const opts = JSON.parse(t.options);
            return (
              <div key={t.id} className="group border border-slate-100 bg-white rounded-lg p-3 hover:border-slate-300 transition-all relative">
                <button
                  onClick={() => removeQuestion(t.id)}
                  className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-red-500 transition-all"
                >
                  <IconTrash />
                </button>
                
                <div className="flex gap-2 mb-2">
                  <span className="text-[10px] font-mono font-bold text-slate-400">Q{i + 1}</span>
                  <p className="text-[11px] font-bold text-slate-800 leading-tight pr-4">
                    {t.question}
                  </p>
                </div>

                <div className="flex flex-wrap gap-1">
                  {opts.map((o, idx) => (
                    <span
                      key={idx}
                      className={`text-[9px] px-1.5 py-0.5 rounded border ${
                        o === t.answer
                          ? "bg-emerald-50 border-emerald-200 text-emerald-700 font-bold"
                          : "bg-slate-50 border-slate-100 text-slate-400"
                      }`}
                    >
                      {o}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}