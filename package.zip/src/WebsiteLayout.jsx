import { Outlet } from "react-router-dom";
import WebsiteHeader from "../components/WebsiteHeader";
import WebsiteFooter from "../components/WebsiteFooter";

export default function WebsiteLayout() {
  return (
    <>
      <WebsiteHeader />
      <main>
        <Outlet />
      </main>
      <WebsiteFooter />
    </>
  );
}
