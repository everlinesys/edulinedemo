import { getUser } from "../auth";
import { useBranding } from "../useBranding";

export default function StudentProfile() {
  const user = getUser();
  const brand = useBranding();
  const theme = brand.theme;

  return (
    <div className={`${theme.layout.container} p-6`}>
      <h2 className={theme.text.title}>My Profile</h2>

      <div className={`mt-6 p-6 ${theme.card.soft}`}>
        <p className={theme.text.body}>Email: {user?.email}</p>
        <p className={theme.text.body}>Name: {user?.name}</p>
      </div>
    </div>
  );
}
