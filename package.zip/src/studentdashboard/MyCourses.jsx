import { useEffect, useState } from "react";
import api from "../api";
import { getUser } from "../auth";
import { useBranding } from "../useBranding";

export default function StudentCourses() {
  const user = getUser();

  const brand = useBranding();
  const theme = brand.theme;

  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await api.get(`/purchase/my?userId=${user.id}`);
        const list = res.data;

        const enriched = await Promise.all(
          list.map(async (p) => {
            console.log("PURCHASED COURSE:", p);
            const course = p.course;

            const progressRes = await api.get(
              `/progress/summary?userId=${user.id}&courseId=${p.courseId}`
            );

            let finalPassed = false;
            try {
              const finalRes = await api.get(
                `/api/test-results/final?courseId=${p.courseId}`
              );
              finalPassed = finalRes.data?.passed === true;
            } catch {
              finalPassed = false;
            }

            return {
              id: p.id,
              courseId: p.courseId,
              title: course?.title ?? "Untitled Course",
              thumbnail: course?.thumbnail ?? null,
              percent: progressRes.data.percent ?? 0,
              completed: progressRes.data.percent === 100,
              finalPassed,
            };
          })
        );

        setCourses(enriched);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [user.id]);

  // ===== LOADING =====
  if (loading) {
    return (
      <div className="p-8 text-center text-sm opacity-60">
        Loading your courses…
      </div>
    );
  }

  return (
    <div
      className={`min-h-screen ${theme.layout.container}`}
      style={{ "--color-primary": brand.colors.primary }}
    >
      <div className="max-w-[1200px] mx-auto px-4 py-10 space-y-8">



        {/* EMPTY STATE */}
        {courses.length === 0 && (
          <div
            className={`
              p-10 text-center space-y-3
              ${theme.layout.panel}
              ${theme.shape.radius}
            `}
          >
            <p className={theme.text.body}>
              You haven’t enrolled in any courses yet.
            </p>

            <button
              onClick={() => window.location = "/courses"}
              className={`
                px-6 py-2 text-sm font-bold
                ${theme.button.primary}
                ${theme.shape.buttonRadius}
              `}
            >
              Browse Courses
            </button>
          </div>
        )}

        {/* COURSE GRID */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((c) => (
            <div
              key={c.id}
              className={`
                flex flex-col overflow-hidden
                transition hover:-translate-y-1
                ${theme.layout.panel}
                ${theme.shape.cardRadius}
              `}
            >
              {/* THUMB */}
              <div className="h-40 bg-black/5 overflow-hidden">
                {c.thumbnail ? (
                  <img
                    src={`${api.defaults.baseURL.replace("/api", "")}${c.thumbnail}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="h-full flex items-center justify-center text-xs opacity-50">
                    No thumbnail
                  </div>
                )}
              </div>

              {/* BODY */}
              <div className="p-5 flex-1 flex flex-col justify-between space-y-4">

                <div className="space-y-2">
                  <h3 className={`font-semibold ${theme.text.title}`}>
                    {c.title}
                  </h3>

                  {/* PROGRESS BAR */}
                  <div className="space-y-1">
                    <div className="h-1.5 bg-black/10 rounded-full overflow-hidden">
                      <div
                        className="h-full transition-all"
                        style={{
                          width: `${c.percent}%`,
                          background: brand.colors.primary,
                        }}
                      />
                    </div>

                    <p className="text-xs opacity-70">
                      {c.percent === 0
                        ? "Not started"
                        : c.percent < 100
                          ? `${c.percent}% completed`
                          : "Course completed"}
                    </p>
                  </div>

                  {/* STATUS BADGES */}
                  {c.completed && !c.finalPassed && (
                    <span className="text-[11px] text-orange-600">
                      Final test pending
                    </span>
                  )}

                  {c.finalPassed && (
                    <span className="text-[11px] text-green-600">
                      Certificate unlocked
                    </span>
                  )}
                </div>

                {/* ACTIONS */}
                <div className="space-y-2">
                  <button
                    onClick={() => window.location = `/dashboard/watch/${c.courseId}`}
                    className={`
    w-full py-2 text-sm font-bold
    ${theme.button.primary}
    ${theme.shape.buttonRadius}
  `}
                  >
                    {c.percent > 0 ? "Resume Learning" : "Start Course"}
                  </button>


                  {c.finalPassed && (
                    <a
                      href={`${api.defaults.baseURL}/api/certificate/${c.courseId}`}
                      target="_blank"
                      rel="noreferrer"
                      className={`
                        block text-center w-full py-2 text-sm font-bold
                        bg-green-600 text-white
                        ${theme.shape.buttonRadius}
                      `}
                    >
                      Download Certificate
                    </a>
                  )}
                </div>

              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
