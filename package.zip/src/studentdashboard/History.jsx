import { useBranding } from "../useBranding";

export default function StudentHistory() {
  const brand = useBranding();
  const theme = brand.theme;

  return (
    <div className={`${theme.layout.container} p-6`}>
      <h2 className={theme.text.title}>Login History</h2>

      <p className={`${theme.text.body} mt-2`}>
        Recent account activity.
      </p>

      <div className={`mt-6 p-6 ${theme.card.soft}`}>
        Login activity will appear here.
      </div>
    </div>
  );
}
