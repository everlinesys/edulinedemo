import { useBranding } from "../useBranding";

export default function StudentCertificates() {
  const brand = useBranding();
  const theme = brand.theme;

  return (
    <div className={`${theme.layout.container} p-6`}>
      <h2 className={theme.text.title}>Certificates</h2>

      <p className={`${theme.text.body} mt-2`}>
        Download certificates for completed courses.
      </p>

      <div className={`mt-6 p-6 ${theme.card.soft}`}>
        You have no certificates yet.
      </div>
    </div>
  );
}
