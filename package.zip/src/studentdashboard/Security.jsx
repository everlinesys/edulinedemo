import { useBranding } from "../useBranding";

export default function StudentSecurity() {
  const brand = useBranding();
  const theme = brand.theme;

  return (
    <div className={`${theme.layout.container} p-6`}>
      <h2 className={theme.text.title}>Security</h2>

      <p className={`${theme.text.body} mt-2`}>
        Manage password and account security.
      </p>

      <div className={`mt-6 p-6 ${theme.card.soft}`}>
        Password change module will go here.
      </div>
    </div>
  );
}
