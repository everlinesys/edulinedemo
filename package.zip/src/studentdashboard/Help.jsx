import { useBranding } from "../useBranding";

export default function StudentHelp() {
  const brand = useBranding();
  const theme = brand.theme;

  return (
    <div className={`${theme.layout.container} p-6`}>
      <h2 className={theme.text.title}>Get Help</h2>

      <p className={`${theme.text.body} mt-2`}>
        Need assistance? We’re here to help.
      </p>

      <div className={`mt-6 p-6 ${theme.card.soft}`}>
        Support system will be integrated here.
      </div>
    </div>
  );
}
