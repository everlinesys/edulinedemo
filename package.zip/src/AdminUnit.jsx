import { useEffect, useState, useRef, useCallback } from "react";
import api from "./api";

// --- ICONS ---
const IconPlus = () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>;
const IconTrash = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 6h18m-2 0v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6m3 0V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"></path></svg>;
const IconEdit = () => <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>;
const IconUpload = () => <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>;

// --- NEW STABLE INPUT COMPONENT ---
// This component aims to keep the DOM input element stable and prevent re-creation.
const StableInput = ({ label, value, onChange, ...props }) => {
  const inputRef = useRef(null);

  // Keep the DOM input's value in sync with the React state value
  useEffect(() => {
    if (inputRef.current && inputRef.current.value !== value) {
      inputRef.current.value = value;
    }
  }, [value]);

  const handleChange = useCallback((e) => {
    // Only call the external onChange if the value actually changed
    if (inputRef.current.value !== value) {
      onChange(e);
    }
  }, [onChange, value]);

  return (
    <div className="mb-4">
      {label && <label className="text-xs text-slate-400 block mb-1">{label}</label>}
      <input
        ref={inputRef}
        {...props}
        defaultValue={value} // Use defaultValue to set initial value, then manage via ref
        onChange={handleChange}
        className="bg-slate-900 border border-slate-800 p-3 rounded-xl text-sm text-white outline-none focus:border-indigo-500 transition-all placeholder:text-slate-600 w-full"
      />
    </div>
  );
};

// --- REFINED FILE INPUT COMPONENT ---
// File inputs are uncontrolled by nature for security reasons.
const FileInput = ({ label, fileRef, ...props }) => (
  <div className="mb-4">
    {label && <label className="text-xs text-slate-400 block mb-1">{label}</label>}
    <input
      ref={fileRef} // Attach the ref here
      type="file"
      className="block w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 cursor-pointer"
      {...props}
    />
  </div>
);

export default function AdminUnit({ unit }) {
  if (!unit) return null;

  const [chapters, setChapters] = useState([]);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);

  // State for the new chapter form (input and file)
  const [newChapterForm, setNewChapterForm] = useState({
    title: "",
    videoFile: null,
    desc: ""
  });

  const videoFileInputRef = useRef(null); // Ref for the actual file input DOM element

  const loadChapters = useCallback(async () => {
    try {
      const c = await api.get(`/chapters?unitId=${unit.id}`);
      setChapters(c.data);
    } catch (error) {
      console.error("Failed to load chapters:", error);
      alert("Failed to load chapters. Check console for details.");
    }
  }, [unit.id]);

  useEffect(() => {
    if (unit.id) {
      loadChapters();
    }
  }, [unit.id, loadChapters]);

  const handleNewChapterFormChange = useCallback((e) => {
    const { name, value, files } = e.target;
    setNewChapterForm(prev => ({
      ...prev,
      [name]: files ? files[0] : value
    }));
  }, []);

  // ============================================================
  // 🔥 BUNNY CHAPTER UPLOAD (FIXED AND SECURED)
  // ============================================================
  async function handleFileUpload(e) {
    e.preventDefault();

    if (!newChapterForm.videoFile || !newChapterForm.title) {
      return alert("Chapter Title and Video File are required.");
    }

    try {
      setUploading(true);
      setUploadProgress(0);

      // 1️⃣ Ask VPS to create Bunny video object AND return the necessary AccessKey
      // Your backend MUST return { videoId, uploadUrl, accessKey }
      const { data } = await api.post(
        "/admin/bunny/create-video-simple",
        { title: newChapterForm.title },
        {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token")
          }
        }
      );

      const { videoId, uploadUrl, accessKey } = data; // Destructure accessKey from backend response

      if (!accessKey) {
        throw new Error("Bunny AccessKey not received from the server. Check your backend endpoint.");
      }

      // 2️⃣ PUT directly to Bunny using the received AccessKey
      await new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        xhr.open("PUT", uploadUrl);
        xhr.setRequestHeader(
          "AccessKey",
          accessKey // Use the AccessKey provided by the backend
        );
        xhr.setRequestHeader(
          "Content-Type",
          newChapterForm.videoFile.type || "application/octet-stream" // Set content type from file
        );

        xhr.upload.onprogress = (event) => {
          if (event.lengthComputable) {
            const percent = Math.floor(
              (event.loaded / event.total) * 100
            );
            setUploadProgress(percent);
          }
        };

        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) { // Check for success status range
            resolve();
          } else {
            console.error("Bunny upload error:", xhr.responseText);
            reject(xhr.responseText || `Bunny upload failed with status ${xhr.status}`);
          }
        };

        xhr.onerror = () => reject("Network error during Bunny upload. Check your internet connection or server logs.");

        xhr.send(newChapterForm.videoFile);
      });

      // 3️⃣ Save chapter with Bunny video ID and the full video URL
      await api.post("/chapters", {
        unitId: unit.id,
        title: newChapterForm.title,
        description: newChapterForm.desc,

        bunnyVideoId: videoId,

        // ✅ THIS IS WHAT BACKEND DEMANDS
        bunnyLibraryId: import.meta.env.VITE_BUNNY_LIBRARY_ID
      },

        {
          headers: { Authorization: "Bearer " + localStorage.getItem("token") }
        });

      // Reset form fields
      setNewChapterForm({
        title: "",
        videoFile: null,
        desc: ""
      });
      if (videoFileInputRef.current) {
        videoFileInputRef.current.value = ""; // Clear the native file input
      }

      loadChapters(); // Reload chapters to show the new one
      alert("Chapter uploaded successfully!");

    } catch (err) {
      console.error("Upload failed:", err);
      alert("Upload failed: " + (err.message || "An unknown error occurred. Check console for details."));
    } finally {
      setUploading(false);
      setUploadProgress(0);
    }
  }

  const handleDeleteChapter = async (id) => {
    if (!window.confirm("Are you sure you want to delete this chapter?")) return;
    try {
      await api.delete(`/chapters/${id}`, {
        headers: { Authorization: "Bearer " + localStorage.getItem("token") }
      });
      loadChapters();
      alert("Chapter deleted successfully!");
    } catch (error) {
      console.error("Failed to delete chapter:", error);
      alert("Failed to delete chapter. Check console for details.");
    }
  };

  return (
    <div className="bg-slate-950 text-white p-8 space-y-12 min-h-screen">

      <section className="max-w-5xl mx-auto">

        <h2 className="text-3xl font-extrabold mb-8 text-indigo-300">
          <span className="text-slate-500 font-semibold text-lg">Unit:</span> {unit.name || unit.title}
        </h2>

        {/* ===== ADD NEW CHAPTER FORM ===== */}
        <form
          onSubmit={handleFileUpload}
          className="bg-slate-900/40 border border-slate-800 p-8 rounded-2xl mb-12 shadow-lg"
        >
          <h3 className="text-xl font-bold mb-6 text-white flex items-center gap-2">
            <IconPlus /> Add New Chapter
          </h3>

          <div className="grid md:grid-cols-2 gap-6">
            <StableInput
              label="Chapter Title"
              name="title"
              placeholder="e.g., Introduction to React Hooks"
              value={newChapterForm.title}
              onChange={handleNewChapterFormChange}
            />

            <FileInput
              label="Video File (Bunny)"
              name="videoFile"
              accept="video/*"
              onChange={handleNewChapterFormChange}
              fileRef={videoFileInputRef}
            />
          </div>

          <div className="mb-6">
            <label className="text-xs text-slate-400 block mb-1">
              Description
            </label>
            <textarea
              name="desc"
              rows="3"
              className="bg-slate-900 border border-slate-800 p-3 rounded-xl text-sm text-white outline-none focus:border-indigo-500 transition-all placeholder:text-slate-600 w-full resize-y"
              placeholder="Brief overview of the chapter content..."
              value={newChapterForm.desc}
              onChange={handleNewChapterFormChange}
            />
          </div>

          <button
            type="submit"
            disabled={uploading}
            className={`w-full py-3 rounded-xl font-bold text-base transition-all flex items-center justify-center gap-2
              ${uploading
                ? "bg-slate-700 text-slate-400 cursor-not-allowed"
                : "bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-md shadow-emerald-500/20 hover:shadow-emerald-500/40"
              }`}
          >
            {uploading ? (
              <>
                <IconUpload /> Uploading {uploadProgress}%
              </>
            ) : (
              <>
                <IconPlus /> Create Chapter
              </>
            )}
          </button>

          {uploading && (
            <div className="mt-4 w-full bg-slate-800 rounded-full h-2.5">
              <div
                className="bg-gradient-to-r from-emerald-400 to-teal-500 h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              />
            </div>
          )}
        </form>

        {/* ===== CHAPTERS LIST ===== */}
        <h3 className="text-2xl font-bold mb-6 text-white">All Chapters ({chapters.length})</h3>
        <div className="space-y-4">
          {chapters.length === 0 && !uploading ? (
            <div className="text-center text-slate-500 p-10 border border-slate-800/50 rounded-xl bg-slate-900/30">
              No chapters yet. Add your first one above!
            </div>
          ) : (
            chapters.map((c) => (
              <div
                key={c.id}
                className="bg-slate-900 border border-slate-800 p-5 rounded-xl flex items-center justify-between gap-4 transition-all duration-200 hover:border-indigo-500/30 hover:shadow-lg hover:shadow-indigo-500/5"
              >
                <div className="flex-1 min-w-0">
                  <h5 className="font-bold text-lg text-white truncate">{c.title}</h5>
                  {c.description && (
                    <p className="text-sm text-slate-400 line-clamp-2 mt-1">
                      {c.description}
                    </p>
                  )}

                  {c.bunnyVideoId && (
                    <span className="text-xs text-indigo-400 block mt-2">
                      Bunny Video ID: {c.bunnyVideoId}
                    </span>
                  )}
                </div>

                <div className="flex-shrink-0 flex gap-2">
                  <button
                    // onClick={() => handleEditChapter(c.id)} // Placeholder for edit functionality
                    className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-300 transition-colors"
                    title="Edit Chapter"
                  >
                    <IconEdit />
                  </button>
                  <button
                    onClick={() => handleDeleteChapter(c.id)}
                    className="p-2 bg-red-900/50 hover:bg-red-800 rounded-lg text-red-300 transition-colors"
                    title="Delete Chapter"
                  >
                    <IconTrash />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
}