import { useBranding } from "./useBranding";

export default function ContactUs() {
  const brand = useBranding();
  const contact = brand.contact || {};
  const primaryColor = brand.colors?.primary || "#0f172a";

  return (
    <section
      className={`
      w-full border-t
      ${brand.theme.layout.container}
      ${brand.theme.shape.radius}
    `}
      style={{ "--color-primary": primaryColor }}
    >
      <div className="max-w-6xl mx-auto px-6 md:px-8 lg:px-12 py-20 lg:py-28 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">

        {/* LEFT */}
        <div className="-y-6">

          <span
            className={`
            inline-block px-3 py-1 text-[10px] uppercase tracking-[0.2em] font-black
            ${brand.theme.badge.base}
            ${brand.theme.shape.buttonRadius}
          `}
          >
            Support Center
          </span>

          <h2
            className={`text-3xl md:text-4xl tracking-tight ${brand.theme.text.title}`}
            style={{ color: primaryColor }}
          >
            Talk to our team
          </h2>

          <p className={`max-w-md text-sm leading-relaxed ${brand.theme.text.body}`}>
            Questions about courses, certifications, or enterprise setup?
            Our dedicated team is here to guide your learning journey.
          </p>

          {/* CONTACT GRID */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-6">

            <div className="space-y-1">
              <p className={`text-[11px] uppercase tracking-widest ${brand.theme.text.label}`}>
                Email Address
              </p>

              <a
                href={`mailto:${contact.email || "support@example.com"}`}
                className={`text-sm font-bold ${brand.theme.text.title} hover:opacity-70 transition`}
              >
                {contact.email || "support@example.com"}
              </a>
            </div>

            <div className="space-y-1">
              <p className={`text-[11px] uppercase tracking-widest ${brand.theme.text.label}`}>
                Phone Support
              </p>

              <p className={`text-sm font-bold ${brand.theme.text.title}`}>
                {contact.phone || "+91 00000 00000"}
              </p>
            </div>

          </div>

          {/* ONLINE STATUS */}
          <div className="pt-4">
            <div
              className={`
              flex items-center gap-3 p-3 w-fit
              ${brand.theme.layout.panel}
              ${brand.theme.shape.cardRadius}
            `}
            >
              <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />

              <span className={`text-[12px] font-bold ${brand.theme.text.body}`}>
                {contact.supportName || "Support Team"} — Online
              </span>
            </div>
          </div>

        </div>

        {/* RIGHT VISUAL */}
        <div
          className={`
          relative w-full aspect-[4/3] lg:aspect-square overflow-hidden shadow-2xl
          ${brand.theme.layout.panel}
          ${brand.theme.shape.radius}
        `}
        >

          {/* GRADIENT LAYER */}
          <div
            className="absolute inset-0 z-0 opacity-40"
            style={{
              background: `radial-gradient(circle at 20% 20%, ${primaryColor}22 0%, transparent 50%)`,
            }}
          />

          <img
            src={
              contact.image ||
              "https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&q=80&w=1000"
            }
            alt="Team Collaboration"
            className="w-full h-full object-cover "
          />

          {/* GLASS CARD */}
          <div
            className={`
            absolute bottom-6 left-6 right-6 backdrop-blur-md p-6 shadow-xl
            ${brand.theme.card?.glass || brand.theme.layout.panel}
            ${brand.theme.shape.cardRadius}
          `}
          >
            <div className="flex flex-col gap-1">

              <p className={`text-[10px] uppercase tracking-[0.2em] font-black ${brand.theme.text.label}`}>
                Response Time
              </p>

              <p className={`text-sm font-bold ${brand.theme.text.title}`}>
                Typically under 2 hours
              </p>

              <p className={`text-[12px] mt-1 leading-snug ${brand.theme.text.body}`}>
                Reliable assistance for learners and organization administrators.
              </p>

            </div>
          </div>

        </div>

      </div>
    </section>
  );

}