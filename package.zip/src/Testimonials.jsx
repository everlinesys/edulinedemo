import { useBranding } from "./useBranding";

export default function Testimonials() {
  const brand = useBranding();

  const reviews = brand.reviews || [];
  const primary = brand.colors?.primary || "#6366f1";

  if (!reviews.length) return null;

  return (
    <section
      className={`
        w-full
        ${brand.theme.layout.container}
      `}
    >
      {/* INNER PADDED CONTAINER */}
      <div
        className="
          mx-auto max-w-[1400px]
          px-4 sm:px-6 md:px-8 lg:px-12
          py-12 md:py-16 lg:py-20
          space-y-12
        "
      >

        {/* ===== HEADER ===== */}
        <div className="flex flex-col items-center text-center space-y-3">

          <div
            className={`
              px-3 py-1 text-[10px] uppercase tracking-widest font-black
              ${brand.theme.badge.base}
              ${brand.theme.shape.buttonRadius}
            `}
            style={{
              backgroundColor: primary + "22",
              color: primary,
            }}
          >
            Success Stories
          </div>

          <h2 className={`text-3xl md:text-4xl tracking-tight ${brand.theme.text.title}`}>
            What our learners say
          </h2>

          <div
            className="h-1 w-12 rounded-full"
            style={{ backgroundColor: primary }}
          />

        </div>

        {/* ===== GRID ===== */}
        <div className="grid md:grid-cols-3 gap-6 md:gap-8">

          {reviews.slice(0, 3).map((t, i) => (
            <div
              key={i}
              className={`
                group relative flex flex-col h-full
                transition-all duration-300 hover:-translate-y-1 hover:shadow-xl
                ${brand.theme.layout.panel}
                ${brand.theme.shape.cardRadius}
                p-6 md:p-8
              `}
            >

              {/* QUOTE ICON */}
              <div
                className="absolute top-6 right-8"
                style={{ color: primary + "11" }}
              >
                <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M14.017 21L14.017 18C14.017 16.8954 14.9124 16 16.017 16H19.017C19.5693 16 20.017 15.5523 20.017 15V9C20.017 8.44772 19.5693 8 19.017 8H15.017C14.4647 8 14.017 8.44772 14.017 9V12C14.017 12.5523 13.5693 13 13.017 13H11.017V21H14.017ZM5.017 21L5.017 18C5.017 16.8954 5.91243 16 7.017 16H10.017C10.5693 16 11.017 15.5523 11.017 15V9C11.017 8.44772 10.5693 8 10.017 8H6.017C5.46472 8 5.017 8.44772 5.017 9V12C5.017 12.5523 4.56928 13 4.017 13H2.017V21H5.017Z" />
                </svg>
              </div>

              <div className="relative z-10 flex flex-col h-full">

                {/* STARS */}
                <div className="flex gap-1 mb-4 text-amber-400">
                  {[...Array(t.rating || 5)].map((_, i) => (
                    <svg key={i} width="14" height="14" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>

                {/* TEXT */}
                <p className={`italic leading-relaxed mb-6 flex-grow ${brand.theme.text.body}`}>
                  “{t.text}”
                </p>

                {/* AUTHOR */}
                <div className="flex items-center gap-4">

                  <div
                    className={`
                      w-10 h-10 flex items-center justify-center
                      text-white font-black text-sm uppercase shadow-lg
                      ${brand.theme.shape.buttonRadius}
                    `}
                    style={{
                      backgroundColor: primary,
                      boxShadow: `0 10px 20px ${primary}33`,
                    }}
                  >
                    {t.name?.charAt(0)}
                  </div>

                  <div>
                    <div className={`text-sm leading-none mb-1 ${brand.theme.text.title}`}>
                      {t.name}
                    </div>

                    <div className={`text-[10px] uppercase tracking-tight ${brand.theme.text.label}`}>
                      {t.role || "Verified Learner"}
                    </div>
                  </div>

                </div>

              </div>

            </div>
          ))}

        </div>

      </div>
    </section>
  );
}
