import { useEffect, useState } from "react";
import { getUser } from "./auth";
import Hero from "./Hero";
import Testimonials from "./Testimonials";
import PreviewVideo from "./PreviewVideo";
import ContactUs from "./contactus";
import api from "./api";
import { useBranding } from "./useBranding";
import VideoPlayer from "./BunnyStream/VideoPlayer";


export default function Courses() {
  const [courses, setCourses] = useState([]);
  const [purchases, setPurchases] = useState([]);
  const [activeCourse, setActiveCourse] = useState(null); // ✅ ADDED
  const brand = useBranding();


  useEffect(() => {
    async function load() {
      const r = await api.get("/courses");
      setCourses(r.data);
      const user = getUser();
      if (!user) {
        setPurchases([]);
        return;
      }

      const pr = await api.get(`/purchase/my?userId=${user.id}`);
      setPurchases(pr.data.map((p) => p.courseId));
    }

    load();
  }, []);

  function isOwned(id) {
    return purchases.includes(id);
  }

  async function buy(courseId) {
    const user = getUser();
    if (!user) {
      window.location = "/register";
      return;
    }

    const orderRes = await api.post("/payments/create-order", {
      courseId,
    });

    let verified = false;

    const options = {
      key: orderRes.data.key,
      amount: orderRes.data.amount,
      currency: orderRes.data.currency,
      order_id: orderRes.data.orderId,
      name: "Course Purchase",
      description: "Access your course immediately",
      handler: async function (response) {
        if (verified) return;
        verified = true;

        await api.post("/payments/verify", {
          razorpay_order_id: response.razorpay_order_id,
          razorpay_payment_id: response.razorpay_payment_id,
          razorpay_signature: response.razorpay_signature,
          courseId,
        });

        setPurchases((prev) => [...prev, courseId]);
        window.location = `/watch/${courseId}`;
      },
    };

    const rzp = new window.Razorpay(options);
    rzp.open();
  }

  return (
    <div
      className=" "
      style={{ "--color-primary": brand.colors.primary }}
    >
      <Hero />

      <div className="max-w-[1400px] mx-automt-12">
        <PreviewVideo />

        {/* Section Header */}
        {/* ===== COURSES SECTION WRAPPER ===== */}
        <section
          className={`
    w-full
    ${brand.theme.layout.container}
  `}
        >
          <div
            className="
      mx-auto max-w-[1400px]
      px-4 sm:px-6 md:px-8 lg:px-12
      py-12 md:py-16 lg:py-20
      space-y-12
    "
          >

            {/* ===== SECTION HEADER ===== */}
            <div className="space-y-3" id="courses">

              <div className="flex items-center gap-2">

                <span
                  className="h-px w-8"
                  style={{ backgroundColor: brand.colors.primary }}
                />

                <span
                  className={`
            text-xs font-bold uppercase tracking-widest
            ${brand.theme.text.label}
          `}
                  style={{ color: brand.colors.primary }}
                >
                  Catalog
                </span>

              </div>

              <h2 className={`text-3xl tracking-tight ${brand.theme.text.title}`}>
                Explore Courses
              </h2>

              <p className={`max-w-xl text-sm ${brand.theme.text.body}`}>
                Premium selection of industry-grade courses designed to take you
                from beginner to professional.
              </p>

            </div>

            {/* ===== COURSE GRID ===== */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">

              {courses.map((c) => (
                <div
                  key={c.id}
                  onClick={(e) => {
                    if (e.target.closest("button")) return;
                    setActiveCourse(c);
                  }}
                  className={`
            group overflow-hidden flex flex-col cursor-pointer
            transition-all duration-300 hover:-translate-y-1 hover:shadow-xl

            ${brand.theme.layout.panel}
            ${brand.theme.shape.cardRadius}
          `}
                >

                  {/* THUMBNAIL */}
                  <div className="relative aspect-video overflow-hidden">

                    <img
                      src={
                        c.thumbnail
                          ? `${import.meta.env.VITE_API_URL.replace("/api", "")}${c.thumbnail}`
                          : "https://via.placeholder.com/600x300?text=No+Image"
                      }
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      alt={c.title}
                    />

                    <div className="absolute top-3 right-3">


                      <div className="text-right">
                        {isOwned(c.id) ? (
                          <span>✨ Enrolled</span>
                        ) : (
                          <>
                            <div className="flex items-center gap-2">
                              <span className="text-lg font-bold">₹{c.price}</span>

                              {c.oldPrice && c.oldPrice > c.price && (
                                <>
                                  <span className="text-xs line-through opacity-60">
                                    ₹{c.oldPrice}
                                  </span>

                                  <span className="text-[10px] bg-green-500/10 text-green-500 px-1.5 py-0.5 rounded">
                                    {Math.round((1 - c.price / c.oldPrice) * 100)}% OFF
                                  </span>
                                </>
                              )}
                            </div>
                          </>
                        )}
                      </div>


                    </div>

                  </div>

                  {/* CONTENT */}
                  <div className="p-6 md:p-7 flex flex-col flex-1">

                    <div className="flex-1 space-y-2">

                      <h3 className={`text-lg leading-tight ${brand.theme.text.title}`}>
                        {c.title}
                      </h3>

                      <p className={`text-sm line-clamp-2 leading-relaxed ${brand.theme.text.body}`}>
                        {c.description}
                      </p>

                    </div>

                    {/* FOOTER */}
                    <div className="mt-6 pt-5 border-t border-black/10 flex items-center justify-between">

                      <div>
                        <span className={`block text-[10px] uppercase font-bold ${brand.theme.text.label}`}>
                          Total Price
                        </span>

                        <span className={`text-lg tracking-tight ${brand.theme.text.title}`}>
                          ₹{c.price}
                        </span>
                      </div>

                      {isOwned(c.id) ? (
                        <button
                          className={`
                    px-6 py-2.5 text-xs font-bold transition-all
                    ${brand.theme.button.secondary}
                    ${brand.theme.shape.buttonRadius}
                  `}
                          onClick={() => (window.location = `/watch/${c.id}`)}
                        >
                          Continue Learning
                        </button>
                      ) : (
                        <button
                          className={`
                    px-6 py-2.5 text-xs font-bold transition-all
                    ${brand.theme.button.primary}
                    ${brand.theme.shape.buttonRadius}
                  `}
                          onClick={() => buy(c.id)}
                        >
                          Unlock Now
                        </button>
                      )}

                    </div>

                  </div>

                </div>
              ))}

            </div>

          </div>
        </section>


        <Testimonials />
        <ContactUs />
      </div>

      {/* ================= COURSE MODAL ================= */}
      {activeCourse && (
        <div className="fixed inset-0 z-50">

          {/* BACKDROP */}
          <div
            className="absolute inset-0 bg-black/70 backdrop-blur-sm"
            onClick={() => setActiveCourse(null)}
          />

          {/* PAGE SURFACE */}
          <div
            className={`
        relative h-full overflow-y-auto
        ${brand.theme.layout.page}
      `}
          >

            {/* PAGE CONTAINER */}
            <div
              className="
          mx-auto max-w-5xl
          px-4 sm:px-6 md:px-8 lg:px-12
          py-16 md:py-20
          min-h-screen
        "
            >

              {/* CONTENT PANEL */}
              <div
                className={`
            relative overflow-hidden shadow-2xl
            ${brand.theme.layout.panel}
            ${brand.theme.shape.radius}
          `}
              >

                {/* CLOSE BUTTON */}
                <button
                  onClick={() => setActiveCourse(null)}
                  className={`
              absolute top-6 right-6 z-20
              w-10 h-10 flex items-center justify-center
              ${brand.theme.layout.panel}
              ${brand.theme.shape.buttonRadius}
              shadow-lg
            `}
                >
                  ✕
                </button>

                {/* VIDEO */}
                {/* VIDEO SECTION */}
                {/* ===== VIDEO SECTION (FIXED SIZE) ===== */}
                {/* ===== VIDEO SECTION (FIXED SIZE) ===== */}
                <div className="w-full">
                  {activeCourse.introBunnyVideoId ? (
                    <div
                      className=" bg-yellow-500     w-full  overflow-hidden  relative  aspect-video    "
                    >

                      <div className="absolute inset-0 w-full h-full bg-yellow-50">
                        <VideoPlayer
                          videoId={activeCourse.introBunnyVideoId}

                          className="w-full h-full object-cover"
                          poster={
                            activeCourse.thumbnail
                              ? `${import.meta.env.VITE_API_URL.replace("/api", "")}${activeCourse.thumbnail}`
                              : undefined
                          }
                        />
                      </div>
                    </div>
                  ) : (
                    <div className="w-full aspect-video flex items-center justify-center text-slate-400 text-sm bg-black">
                      Preview video processing or not available
                    </div>
                  )}
                </div>




                {/* BODY */}
                <div className="p-8 md:p-12 lg:p-14 space-y-10">

                  {/* TITLE */}
                  <div className="space-y-4">
                    <h2 className={`text-3xl md:text-4xl ${brand.theme.text.title}`}>
                      {activeCourse.title}
                    </h2>

                    <p className={`max-w-2xl leading-relaxed ${brand.theme.text.body}`}>
                      {activeCourse.description}
                    </p>
                  </div>

                  {/* META GRID */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-8">

                    <div>
                      <p className={`text-xs uppercase ${brand.theme.text.label}`}>
                        Price
                      </p>
                      <div className="flex items-center gap-2">
                        <span className={`text-xl ${brand.theme.text.title}`}>
                          ₹{activeCourse.price}
                        </span>

                        {activeCourse.oldPrice &&
                          activeCourse.oldPrice > activeCourse.price && (
                            <>
                              <span className="text-sm line-through opacity-60">
                                ₹{activeCourse.oldPrice}
                              </span>

                              <span className="text-[10px] bg-green-500/10 text-green-500 px-2 py-1 rounded">
                                {Math.round(
                                  (1 - activeCourse.price / activeCourse.oldPrice) * 100
                                )}
                                % OFF
                              </span>
                            </>
                          )}
                      </div>

                    </div>

                    <div>
                      <p className={`text-xs uppercase ${brand.theme.text.label}`}>
                        Access
                      </p>
                      <p className={brand.theme.text.body}>Lifetime</p>
                    </div>

                    <div>
                      <p className={`text-xs uppercase ${brand.theme.text.label}`}>
                        Level
                      </p>
                      <p className={brand.theme.text.body}>Beginner → Advanced</p>
                    </div>

                    <div>
                      <p className={`text-xs uppercase ${brand.theme.text.label}`}>
                        Certificate
                      </p>
                      <p className={brand.theme.text.body}>Included</p>
                    </div>

                  </div>

                  {/* ACTIONS */}
                  <div className="flex flex-wrap gap-4 pt-4">

                    {isOwned(activeCourse.id) ? (
                      <button
                        className={`
                    px-8 py-3 font-bold
                    ${brand.theme.button.secondary}
                    ${brand.theme.shape.buttonRadius}
                  `}
                        onClick={() =>
                          (window.location = `/watch/${activeCourse.id}`)
                        }
                      >
                        Continue Learning
                      </button>
                    ) : (
                      <button
                        className={`
                    px-8 py-3 font-bold
                    ${brand.theme.button.primary}
                    ${brand.theme.shape.buttonRadius}
                  `}
                        onClick={() => buy(activeCourse.id)}
                      >
                        Purchase Course
                      </button>
                    )}

                    <button
                      onClick={() => setActiveCourse(null)}
                      className={`
                  px-6 py-3 font-bold border border-black/20
                  ${brand.theme.shape.buttonRadius}
                `}
                    >
                      Close
                    </button>

                  </div>

                </div>

              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
}
