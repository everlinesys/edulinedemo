import { useEffect, useState } from "react";
import api from "./api";
import AdminUnit from "./AdminUnit";
import AdminFinalTest from "./AdminFinalTest";

const IconChevron = ({ open }) => (
  <svg className={`transition-transform duration-300 ${open ? "rotate-180" : ""}`} width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
);

export default function AdminUnits({ courseId }) {
  const [units, setUnits] = useState([]);
  const [title, setTitle] = useState("");
  const [course, setCourse] = useState({});
  const [openUnits, setOpenUnits] = useState({}); // Tracks which accordions are open

  const load = async () => {
    const [uRes, cRes] = await Promise.all([
      api.get(`/units?courseId=${courseId}`),
      api.get(`/courses/${courseId}`)
    ]);
    setUnits(uRes.data);
    setCourse(cRes.data);
  };

  useEffect(() => { load(); }, [courseId]);

  const toggleUnit = (id) => setOpenUnits(prev => ({ ...prev, [id]: !prev[id] }));

  return (
    <div className="min-h-screen bg-slate-950 text-white flex flex-col lg:flex-row">
      
      {/* LEFT SIDEBAR: EXPANDABLE NAVIGATOR */}
      <aside className="w-full lg:w-80 h-screen sticky top-0 bg-slate-900/40 border-r border-slate-800 backdrop-blur-xl flex flex-col">
        <div className="p-6 border-b border-slate-800">
          <span className="text-[10px] font-black text-indigo-500 uppercase tracking-widest block mb-1">Course Structure</span>
          <h1 className="text-xl font-bold truncate">{course.title}</h1>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2 custom-scrollbar">
          {units.map((unit, uIdx) => (
            <div key={unit.id} className="space-y-1">
              <button 
                onClick={() => toggleUnit(unit.id)}
                className={`w-full flex items-center justify-between p-3 rounded-xl transition-all ${openUnits[unit.id] ? 'bg-indigo-600/10 text-indigo-400' : 'hover:bg-slate-800 text-slate-400'}`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-[10px] font-bold opacity-50">{uIdx + 1}</span>
                  <span className="text-sm font-semibold truncate max-w-[160px]">{unit.title}</span>
                </div>
                <IconChevron open={openUnits[unit.id]} />
              </button>

              {/* EXPANDABLE CHAPTER LIST */}
              {openUnits[unit.id] && (
                <div className="ml-6 pl-4 border-l border-slate-800 space-y-1 py-1 animate-in slide-in-from-top-2 duration-300">
                  {/* Note: This assumes your unit object includes its chapters. 
                      If not, you can fetch chapters in the AdminUnit component or map them here */}
                  {unit.chapters?.length > 0 ? (
                    unit.chapters.map((ch, cIdx) => (
                      <div key={ch.id} className="text-[11px] py-2 text-slate-500 hover:text-white cursor-pointer transition-colors flex items-center gap-2">
                        <div className="w-1 h-1 rounded-full bg-slate-700" />
                        <span className="truncate">Part {cIdx + 1}: {ch.title}</span>
                      </div>
                    ))
                  ) : (
                    <div className="text-[10px] italic text-slate-700 py-1">No chapters yet</div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="p-4 border-t border-slate-800">
          <form onSubmit={async (e) => {
              e.preventDefault(); if (!title.trim()) return;
              await api.post("/units", { courseId, title });
              setTitle(""); load();
            }} className="relative">
            <input 
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-xs outline-none focus:border-indigo-500 transition-all pr-10"
              placeholder="New Unit Name..."
              value={title}
              onChange={e => setTitle(e.target.value)}
            />
            <button className="absolute right-3 top-3 text-indigo-500 hover:text-white transition-colors">
               <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
            </button>
          </form>
        </div>
      </aside>

      {/* MAIN CONTENT FEED */}
      <main className="flex-1 p-6 lg:p-12 overflow-y-auto bg-slate-950">
        <div className="max-w-4xl mx-auto space-y-12">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold tracking-tight">Curriculum Editor</h2>
            <AdminFinalTest courseId={courseId} />
          </div>

          <div className="space-y-10">
            {units.map((unit, index) => (
              <section key={unit.id} className="bg-slate-900/20 border border-slate-800/60 rounded-[2.5rem] p-8 hover:border-slate-700 transition-all">
                <AdminUnit unit={unit} index={index} />
              </section>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}