import {
    LayoutDashboard,
    BookOpen,
    Award,
    UserSquare2,
    HelpCircle,
    Search,
    User,
    Lock,
    History,
    LogOut,
    ChevronLeft,
    ChevronRight,
    
} from "lucide-react";
import { useState, useEffect } from "react";
import { getUser } from "./auth";
import { useBranding } from "./useBranding";
import api from "./api";
import Watch from "./Watch";
import StudentCertificates from "./studentdashboard/Certificates";
import StudentSecurity from "./studentdashboard/Security";
import StudentHistory from "./studentdashboard/History";
import MyCourses from "./studentdashboard/MyCourses";
import StudentDashboard from "./StudentDashboard";
import StudentEducator from "./studentdashboard/MyCourses";
import StudentHelp from "./studentdashboard/Help";
import StudentExplore from "./studentdashboard/Explore";
import StudentProfile from "./studentdashboard/Profile";
export default function StudentLayout({ children }) {
    const user = getUser();
    const brand = useBranding();
    const theme = brand.theme;

    const [progress, setProgress] = useState(0);
    const [isCollapsed, setIsCollapsed] = useState(false);

    useEffect(() => {
        async function load() {
            try {
                const res = await api.get(`/progress/overall?userId=${user.id}`);
                setProgress(res.data.percent ?? 0);
            } catch {
                setProgress(0);
            }
        }

        if (user?.id) load();
    }, [user?.id]);

    const signOut = () => {
        localStorage.removeItem("token");
        window.location = "/login";
    };

    const menu = [
        { path: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
        { path: "/dashboard/courses", label: "My Courses", icon: BookOpen },
        { path: "/dashboard/certificates", label: "Certificates", icon: Award },
        { path: "/dashboard/educator", label: "My Educator", icon: UserSquare2 },
        { path: "/dashboard/help", label: "Get Help", icon: HelpCircle },
        { path: "/dashboard/explore", label: "Explore", icon: Search },

        { divider: true },

        { path: "/dashboard/profile", label: "Profile", icon: User },
        { path: "/dashboard/security", label: "Security", icon: Lock },
        { path: "/dashboard/history", label: "History", icon: History },

        { divider: true },

        { action: signOut, label: "Sign Out", icon: LogOut, isDestructive: true },
    ];

    const currentPath = window.location.pathname;
    const isWatch = currentPath.startsWith("/dashboard/watch/");
    const courseId = isWatch ? currentPath.split("/dashboard/watch/")[1] : null;
    function renderView() {
        // Watch page special
        if (isWatch) {
            return <Watch courseId={courseId} />;
        }

        switch (currentPath) {
            case "/dashboard":
                return <StudentDashboard />;

            case "/dashboard/courses":
                return <MyCourses />;

            case "/dashboard/certificates":
                return <StudentCertificates />;

            case "/dashboard/educator":
                return <StudentEducator />;

            case "/dashboard/help":
                return <StudentHelp />;

            case "/dashboard/explore":
                return <StudentExplore />;

            case "/dashboard/profile":
                return <StudentProfile />;

            case "/dashboard/security":
                return <StudentSecurity />;

            case "/dashboard/history":
                return <StudentHistory />;

            default:
                return <StudentDashboard />;
        }
    }

    return (
        <div className={`${theme.layout.page} min-h-screen flex`}>
            {/* ===== SIDEBAR ===== */}
            <aside
                className={`
          ${isCollapsed ? "w-[64px]" : "w-[240px]"}
          flex flex-col h-screen sticky top-0
          ${theme.layout.panel}
          transition-all duration-200
        `}
            >
                {/* HEADER */}
                <div className={`h-14 flex items-center px-4 ${theme.layout.header}`}
                    style={{ background: " #edece8", hoverBackground: "##faf9f7", borderRadius: "0px" }}>
                    {!isCollapsed && (
                        <span className={`${theme.text.title} uppercase tracking-wider`}>
                            Student Portal
                        </span>
                    )}

                    <button
                        onClick={() => setIsCollapsed(!isCollapsed)}
                        className="ml-auto p-1"
                        style={{ background: " #edece8", hoverBackground: "##faf9f7", borderRadius: "0px" }}

                    >
                        {isCollapsed ? (
                            <ChevronRight size={16} />
                        ) : (
                            <ChevronLeft size={16} />
                        )}
                    </button>
                </div>

                {/* NAV */}
                <nav className="flex-1">
                    {menu.map((item, i) => {
                        if (item.divider) {
                            return (
                                <div
                                    key={i}
                                    className="h-px bg-gray-200 my-2 opacity-60"
                                />
                            );
                        }

                        const Icon = item.icon;
                        const active = currentPath === item.path;



                        const activeStyle = active
                            ? theme.button.activemenu ?? theme.button.primary
                            : theme.button.menu ?? theme.button.secondary;

                        const destructive = item.isDestructive
                            ? theme.button.danger
                            : activeStyle;

                        const content = (
                            <>
                                <Icon size={16} />
                                {!isCollapsed && (
                                    <span className="ml-3 text-xs">
                                        {item.label}
                                    </span>
                                )}
                            </>
                        );

                        return item.action ? (
                            <button
                                key={i}
                                onClick={item.action}
                                className={` w-full flex items-center h-10 transition-colors  ${isCollapsed ? "justify-center" : "px-4"}  ${destructive}`}
                            >
                                {content}
                            </button>
                        ) : (
                            <button
                                key={i}
                                onClick={() => (window.location = item.path)}
                                className={`w-full flex items-center h-10 transition-colors  ${isCollapsed ? "justify-center" : "px-4"} `}
                                style={{ background: " #edece8", hoverBackground: "##faf9f7", textColor: active ? "#000000" : "#555555", borderRadius: 0 }}

                            >
                                {content}
                            </button>
                        );
                    })}
                </nav>

                {/* PROGRESS */}
                {!isCollapsed && (
                    <div className={`p-4 ${theme.layout.footer}`}>
                        <div className="flex justify-between text-[10px] mb-2">
                            <span className={theme.text.label}>Progress</span>
                            <span className={theme.text.label}>{progress}%</span>
                        </div>

                        <div className="h-1 bg-gray-200">
                            <div
                                className="h-full transition-all"
                                style={{
                                    width: `${progress}%`,
                                    background: brand.colors.primary,
                                }}
                            />
                        </div>
                    </div>
                )}
            </aside>

            {/* MAIN */}
            <main className="flex-1">
                <div className="p-0">
                    {renderView()}
                </div>
            </main>

        </div>
    );
}
