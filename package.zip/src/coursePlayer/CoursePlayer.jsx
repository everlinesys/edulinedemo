import { useEffect, useRef } from "react";
import Plyr from "plyr";
import "plyr/dist/plyr.css";

const getCleanYoutubeID = (url) => {
    if (!url) return null;
    const match = url.match(
        /^.*(?:youtu\.be\/|v\/|embed\/|shorts\/|watch\?v=)([^#&?]{11}).*/
    );
    return match ? match[1] : null;
};

export default function CoursePlayer({ videoUrl, onEnded }) {
    const containerRef = useRef(null);
    const playerRef = useRef(null);
    const onEndedRef = useRef(onEnded);

    useEffect(() => {
        onEndedRef.current = onEnded;
    }, [onEnded]);

    const videoId = getCleanYoutubeID(videoUrl);

    useEffect(() => {
        if (!containerRef.current || !videoId) return;

        // Create the wrapper structure with specific Plyr classes
        containerRef.current.innerHTML = `
            <div class="plyr__video-embed" id="player">
                <iframe
                    src="https://www.youtube-nocookie.com/embed/${videoId}?origin=${window.location.origin}&iv_load_policy=3&modestbranding=1&playsinline=1&showinfo=0&rel=0&enablejsapi=1"
                    allowfullscreen
                    allowtransparency
                    allow="autoplay"
                ></iframe>
            </div>
        `;

        const player = new Plyr(containerRef.current.querySelector(".plyr__video-embed"), {
            autoplay: true,
            ratio: '16:9', // 🧠 Forces the aspect ratio
            resetOnEnd: true,
            youtube: {
                noCookie: true,
                rel: 0,
                showinfo: 0,
                iv_load_policy: 3,
                modestbranding: 1
            },
            controls: [
                "play-large", "play", "progress", "current-time",
                "mute", "volume", "fullscreen"
            ],
        });

        playerRef.current = player;

        player.on("ended", () => {
            onEndedRef.current?.();
        });

        return () => {
            if (playerRef.current) {
                playerRef.current.destroy();
                playerRef.current = null;
            }
            if (containerRef.current) {
                containerRef.current.innerHTML = "";
            }
        };
    }, [videoId]);

    if (!videoId) return <div className="text-white p-6 bg-slate-900 rounded-xl">Video unavailable</div>;

    return (
        <div className="relative w-full aspect-video bg-black rounded-xl overflow-hidden group shadow-xl">
            {/* LABELS OVERLAY */}
            {/* <div className="absolute top-4 left-4 z-20 flex flex-col gap-1 pointer-events-none">
                <span className="bg-black/40 backdrop-blur-md text-white/90 px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase border border-white/10 w-fit">
                    Powered by Google
                </span>

            </div> */}
            <div className="absolute bottom-1 left-4 z-1 flex flex-col gap-1 pointer-events-none" >

                <span className=" text-white/60 px-3 py-0.5 rounded-full text-[9px] font-medium w-fit">
                    Video quality adapts based on your internet speed
                </span>
            </div>
            <style>{`
                /* 1. Force the container to 16:9 and hide scale overflow */
                .plyr__video-embed {
                    padding-bottom: 56.25% !important; /* 16:9 Ratio */
                    height: 0;
                    position: relative;
                    overflow: hidden;
                  
                }

                /* 2. Center and scale the iframe to hide watermarks */
                .plyr__video-embed iframe {
                    position: absolute;
                    top: 50% !important;
                    left: 50% !important;
                    width: 100% !important;
                    height: 100% !important;
                    transform: translate(-50%, -50%) scale(1) !important;
                    pointer-events: none !important;
                }

                /* 3. Re-enable clicks for Plyr controls only */
                .plyr__controls, 
                .plyr__control--overlaid,
                .plyr__video-wrapper { 
                    pointer-events: auto !important; 
                }

                /* 4. Fix range input (progress bar) clickability */
                .plyr--full-ui input[type='range'] {
                    pointer-events: auto !important;
                    cursor: pointer;
                }
                
                /* 5. Hide YouTube logo in bottom right specifically */
                .plyr__video-embed::after {
                    content: "";
                    position: absolute;
                    bottom: 0;
                    right: 0;
                    width: 100px;
                    height: 50px;
                    background: transparent;
                    z-index: 10;
                }
            `}</style>

            <div
                ref={containerRef}
                className="w-full h-full"
            />
        </div>
    );
}