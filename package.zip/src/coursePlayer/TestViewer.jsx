import { useState } from "react";

const IconCheck = () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>;
const IconX = () => <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>;

export default function TestViewer({ test, mode = "unit", onSubmit, onCancel }) {
  if (!test || (Array.isArray(test) && test.length === 0)) {
    return (
      <div className="bg-white rounded-xl p-6 text-center max-w-sm mx-auto border border-slate-200">
        <p className="text-slate-500 text-xs font-bold uppercase">Unavailable</p>
        <button onClick={onCancel} className="mt-4 px-4 py-2 bg-slate-900 text-white rounded-lg font-bold text-xs">Return</button>
      </div>
    );
  }

  const questions = Array.isArray(test) ? test : [test];
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(null);
  const [correctCount, setCorrectCount] = useState(0);

  const selectAnswer = (qIndex, option) => !submitted && setAnswers(prev => ({ ...prev, [qIndex]: option }));

  const handleSubmit = () => {
    if (Object.keys(answers).length !== questions.length) return alert("Complete all questions.");
    let correct = 0;
    questions.forEach((q, i) => { if (answers[i] === q.answer) correct++; });
    const percent = Math.round((correct / questions.length) * 100);
    setCorrectCount(correct);
    setScore(percent);
    setSubmitted(true);
    if (mode === "final" && onSubmit) onSubmit({ score: percent });
  };

  const retryTest = () => { setAnswers({}); setSubmitted(false); setScore(null); };

  return (
    <div className="bg-white border border-slate-200 rounded-xl max-w-2xl mx-auto overflow-hidden shadow-sm">
      {/* COMPACT HEADER */}
      <div className="px-4 py-3 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
        <div>
          <h2 className="text-sm font-black text-slate-800 flex items-center gap-2 uppercase tracking-tight">
            <span className="bg-slate-900 text-white px-1.5 py-0.5 rounded text-[10px]">{mode === "final" ? "EXAM" : "QUIZ"}</span>
            {mode === "final" ? "Final Assessment" : "Unit Review"}
          </h2>
        </div>
        <button onClick={onCancel} className="text-slate-400 hover:text-slate-600"><IconX /></button>
      </div>

      <div className="p-4">
        {/* COMPACT RESULT SUMMARY */}
        {submitted && (
          <div className="mb-6 p-4 rounded-lg bg-slate-900 text-white flex items-center justify-between border border-slate-800">
            <div>
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Result</p>
              <h3 className="text-2xl font-black">{score}% <span className="text-xs font-normal text-slate-400">({correctCount}/{questions.length})</span></h3>
            </div>
            {mode === "final" && (
              <div className="flex items-center gap-1.5 text-emerald-400 text-[10px] font-bold bg-emerald-400/10 px-2 py-1 rounded">
                <IconCheck /> RECORDED
              </div>
            )}
          </div>
        )}

        {/* QUESTIONS LIST */}
        <div className="space-y-6">
          {questions.map((q, qIndex) => {
            const options = Array.isArray(q.options) ? q.options : JSON.parse(q.options);
            return (
              <div key={q.id ?? qIndex} className="space-y-2">
                <div className="flex gap-2">
                  <span className="text-xs font-black text-slate-300 font-mono pt-0.5">{(qIndex + 1).toString().padStart(2, '0')}</span>
                  <p className="font-bold text-slate-800 text-sm leading-tight">{q.question}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5 ml-6">
                  {options.map((opt, idx) => {
                    const isSelected = answers[qIndex] === opt;
                    const isCorrect = submitted && opt === q.answer;
                    const isWrong = submitted && isSelected && opt !== q.answer;

                    let btnClass = "bg-white border-slate-200 text-slate-600 hover:bg-slate-50";
                    if (isSelected && !submitted) btnClass = "bg-slate-800 border-slate-800 text-white";
                    if (isCorrect) btnClass = "bg-emerald-50 border-emerald-500 text-emerald-700 font-black";
                    if (isWrong) btnClass = "bg-red-50 border-red-500 text-red-700 opacity-80";

                    return (
                      <button
                        key={idx}
                        disabled={submitted}
                        onClick={() => selectAnswer(qIndex, opt)}
                        className={`px-3 py-2 rounded-md border text-[11px] font-semibold text-left transition-all flex items-center justify-between ${btnClass}`}
                      >
                        <span className="truncate">{opt}</span>
                        {isCorrect && <IconCheck />}
                        {isWrong && <IconX />}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* COMPACT FOOTER ACTIONS */}
        <div className="mt-8 pt-4 border-t border-slate-100 flex items-center justify-between">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">
            {submitted ? "Completed" : `${Object.keys(answers).length} / ${questions.length} answered`}
          </span>
          <div className="flex gap-2">
            {!submitted ? (
              <button onClick={handleSubmit} className="px-5 py-2 bg-slate-900 text-white rounded-lg font-bold text-xs hover:bg-black transition-all">
                Submit Test
              </button>
            ) : (
              <>
                {mode === "unit" && (
                  <button onClick={retryTest} className="px-4 py-2 border border-slate-200 rounded-lg font-bold text-xs text-slate-600 hover:bg-slate-50">
                    Retry
                  </button>
                )}
                <button onClick={onCancel} className="px-5 py-2 bg-slate-900 text-white rounded-lg font-bold text-xs">
                  Done
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}