import { useEffect, useState } from "react";
import api from "../api";
import { getUser } from "../auth";

export function useCourseData(courseId) {
  const user = getUser();

  // =======================
  // STATE
  // =======================
  const [courseTitle, setCourseTitle] = useState(null);
  const [units, setUnits] = useState([]);
  const [chaptersByUnit, setChaptersByUnit] = useState({});
  const [testsByUnit, setTestsByUnit] = useState({});
  const [progress, setProgress] = useState([]);

  const [current, setCurrent] = useState(null);
  const [openUnitId, setOpenUnitId] = useState(null);

  // =======================
  // LOAD COURSE DATA
  // =======================
  useEffect(() => {
    async function load() {
      // --- Course meta ---
      const courseRes = await api.get(`/courses/${courseId}`);
      setCourseTitle(courseRes.data.title);

      // --- Units ---
      const u = await api.get(`/units?courseId=${courseId}`);
      setUnits(u.data);

      const chapterMap = {};
      const testMap = {};

      for (const unit of u.data) {
        const c = await api.get(`/chapters?unitId=${unit.id}`);
        chapterMap[unit.id] = c.data.sort((a, b) => a.order - b.order);

        const t = await api.get(`/tests?unitId=${unit.id}`);
        testMap[unit.id] = t.data || [];
      }

      setChaptersByUnit(chapterMap);
      setTestsByUnit(testMap);

      // --- Progress ---
      const p = await api.get(
        `/progress/my?courseId=${courseId}&userId=${user.id}`,
      );
      const progressData = p.data || [];
      setProgress(progressData);

      // --- Resume logic ---
      for (const unit of u.data) {
        const chapters = chapterMap[unit.id] || [];
        const incomplete = chapters.find(
          (c) => !progressData.some((p) => p.chapterId === c.id && p.completed),
        );

        if (incomplete) {
          setCurrent({ unitId: unit.id, chapter: incomplete });
          setOpenUnitId(unit.id);
          return;
        }
      }

      // --- All completed fallback ---
      if (u.data.length > 0) {
        const firstUnit = u.data[0];
        setCurrent({
          unitId: firstUnit.id,
          chapter: chapterMap[firstUnit.id][0],
        });
        setOpenUnitId(firstUnit.id);
      }
    }

    load().catch(console.error);
  }, [courseId, user.id]);

  // =======================
  // HELPERS
  // =======================
  const isCompleted = (chapterId) =>
    progress.some((p) => p.chapterId === chapterId && p.completed);

  const isUnitCompleted = (unitId) => {
    const chapters = chaptersByUnit[unitId] || [];
    return chapters.length > 0 && chapters.every((ch) => isCompleted(ch.id));
  };

  const isUnitUnlocked = (unitIndex) => {
    if (unitIndex === 0) return true;
    const prevUnit = units[unitIndex - 1];
    return prevUnit ? isUnitCompleted(prevUnit.id) : false;
  };

  const isChapterUnlocked = (unitId, chapterIndex) => {
    if (chapterIndex === 0) return true;
    const prevChapter = chaptersByUnit[unitId]?.[chapterIndex - 1];
    return prevChapter ? isCompleted(prevChapter.id) : false;
  };

  // =======================
  // CHAPTER COMPLETION
  // =======================
  async function completeChapter(unitId, chapterId) {
    if (isCompleted(chapterId)) return;

    // Optimistic update
    setProgress((prev) => [...prev, { chapterId, completed: true }]);

    // Move forward immediately
    playNext(unitId, chapterId);

    // Persist
    try {
      await api.post("/progress", {
        userId: user.id,
        courseId: Number(courseId),
        unitId,
        chapterId,
        completed: true,
        time: 999,
      });
    } catch (err) {
      console.error("Progress save failed", err);
    }
  }

  // =======================
  // NAVIGATION
  // =======================
  function playNext(unitId, chapterId) {
    const chapters = chaptersByUnit[unitId] || [];
    const index = chapters.findIndex((c) => c.id === chapterId);

    // ▶ 1. Next chapter in same unit
    if (index !== -1 && index < chapters.length - 1) {
      setCurrent({ unitId, chapter: chapters[index + 1] });
      return;
    }

    // ▶ 2. We finished LAST chapter of this unit
    // → unlock next unit IMMEDIATELY
    const unitIndex = units.findIndex((u) => u.id === unitId);

    if (unitIndex !== -1 && unitIndex < units.length - 1) {
      const nextUnit = units[unitIndex + 1];
      const nextChapters = chaptersByUnit[nextUnit.id] || [];

      if (nextChapters.length > 0) {
        setOpenUnitId(nextUnit.id);

        setCurrent({
          unitId: nextUnit.id,
          chapter: nextChapters[0],
        });

        return;
      }
    }

    // ▶ 3. If no more units → course finished
    // (final test logic will handle next screen)
  }

  const isCourseCompleted = () => {
    let total = 0;
    let done = 0;

    units.forEach((u) => {
      const chs = chaptersByUnit[u.id] || [];
      total += chs.length;
      chs.forEach((c) => {
        if (isCompleted(c.id)) done++;
      });
    });

    return total > 0 && total === done;
  };

  // =======================
  // EXPORT
  // =======================
  return {
    courseTitle,
    units,
    chaptersByUnit,
    testsByUnit,

    current,
    openUnitId,
    setOpenUnitId,
    setCurrent,

    isCompleted,
    isUnitCompleted,
    isUnitUnlocked,
    isChapterUnlocked,

    isCourseCompleted,
    completeChapter,
  };
}
