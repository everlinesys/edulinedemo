export default function UnitTestCard({ test, onStart }) {
  return (
    <div
      onClick={onStart}
      className="mt-2 p-3 rounded-lg border border-amber-200 bg-amber-50 
                 hover:bg-amber-100 cursor-pointer transition"
    >
      <div className="flex items-center gap-2 text-sm font-medium text-amber-700">
        📝 Unit Test
      </div>

      <div className="text-xs text-slate-600 mt-1">
        {test.title}
      </div>
    </div>
  );
}
