import { useState, useEffect } from "react";
import api from "./api";
import AdminUnits from "./AdminUnits"; // Assuming this is a component you want to use for curriculum management

// You'll need to make sure 'tus' is available globally or imported if it's a module.
// For example: import * as tus from 'tus-js-client';
// For this example, I'll assume it's globally available as it was in your original code.
// const tus = window.tus; // Uncomment if tus is loaded as a global script.

export default function CourseEditor() {
    // ================= MODE CONTROL =================
    const [mode, setMode] = useState("meta"); // meta | curriculum
    const [activeCourseId, setActiveCourseId] = useState(null);

    // ================= YOUR ORIGINAL STATES =================
    const [courses, setCourses] = useState([]);
    const [editing, setEditing] = useState(null);

    const [uploading, setUploading] = useState(false);
    const [uploadProgress, setUploadProgress] = useState(0);

    const [overviewFile, setOverviewFile] = useState(null);

    const [errors, setErrors] = useState({});

    const [form, setForm] = useState({
        title: "",
        description: "",
        price: "",
        oldPrice: "",
        thumbnail: "",

        introBunnyVideoId: "",
        introVideoUrl: "",
    });

    // ================= SWITCH TO CURRICULUM =================
    

    // ================= LOAD =================
    async function load() {
        const r = await api.get("/courses");
        setCourses(r.data);
    }

    useEffect(() => {
        load();
    }, []);

    // ================= VALIDATION =================
    function runValidation(f) {
        const e = {};

        if (!f.title || f.title.length < 5)
            e.title = "Minimum 5 characters required";

        if (!f.description || f.description.length < 20)
            e.description = "At least 20 characters";

        if (!f.price || Number(f.price) <= 0)
            e.price = "Enter valid selling price";

        if (f.oldPrice && Number(f.oldPrice) <= Number(f.price))
            e.oldPrice = "Old price must be higher than selling price";

        if (!f.thumbnail)
            e.thumbnail = "Thumbnail is required";

        return e;
    }

    useEffect(() => {
        setErrors(runValidation(form));
    }, [form]);

    const isValid = Object.keys(errors).length === 0;

    // ================= FAKE PROGRESS (if still needed, though simpleUpload/tus has its own) =================
    // Removed `simulateProgress` as the actual upload functions handle progress.

    // ================= THUMBNAIL =================
    async function uploadThumbnail(file) {
        if (!file) return;

        const fd = new FormData();
        fd.append("thumbnail", file);

        setUploading(true);

        try {
            const res = await api.post(
                "/uploads/course-thumbnail",
                fd,
                {
                    headers: {
                        Authorization: "Bearer " + localStorage.getItem("token"),
                        "Content-Type": "multipart/form-data",
                    },
                }
            );

            setForm(p => ({...p, thumbnail: res.data.url }));

        } finally {
            setUploading(false);
        }
    }

    // ================= OVERVIEW VIDEO =================
    // FIXED: uploadOverviewVideo function (assuming 'tus' is available)
    async function uploadOverviewVideo() {
        if (!overviewFile) return alert("Select video");

        try {
            setUploading(true);

            // 1. Get IDs and Signature from your VPS
            const res = await api.post("/admin/bunny/create-video", {
                title: form.title
            });
            const { videoId, signature, libraryId } = res.data;

            // 2. Start the TUS upload directly to Bunny
            const upload = new tus.Upload(overviewFile, {
                endpoint: "https://video.bunnycdn.com/tusupload",
                retryDelays: [0, 3000, 5000],
                headers: {
                    "AuthorizationToken": signature,
                    "VideoId": videoId,
                    "LibraryId": libraryId,
                },
                metadata: {
                    filename: overviewFile.name,
                    filetype: overviewFile.type
                },
                onError: (error) => {
                    console.error("Upload failed:", error);
                    setUploading(false);
                },
                onProgress: (bytesSent, bytesTotal) => {
                    setUploadProgress(Math.floor((bytesSent / bytesTotal) * 100));
                },
                onSuccess: () => {
                    setForm(p => ({
                       ...p,
                        introBunnyVideoId: videoId,
                        introVideoUrl: `https://iframe.mediadelivery.net/play/${libraryId}/${videoId}`
                    }));
                    setUploading(false);
                    alert("Upload Complete!");
                }
            });

            upload.start();
        } catch (err) {
            setUploading(false);
            alert("Server error: " + err.message);
        }
    }

    async function simpleUpload(file) {
        if (!file) return alert("Select video first");

        try {
            setUploading(true);
            setUploadProgress(0);

            // 1. Ask your server to create Bunny video
            const { data } = await api.post(
                "/admin/bunny/create-video-simple",
                {
                    title: file.name
                },
                {
                    headers: {
                        Authorization: "Bearer " + localStorage.getItem("token")
                    }
                }
            );

            const { videoId, uploadUrl } = data;

            console.log("🎬 Uploading to:", uploadUrl);

            // 2. Direct PUT to Bunny
            return new Promise((resolve, reject) => {

                const xhr = new XMLHttpRequest();

                xhr.open("PUT", uploadUrl);

                // IMPORTANT: Bunny auth via header from your server session
                xhr.setRequestHeader(
                    "AccessKey",
                    import.meta.env.VITE_BUNNY_STREAM_API_KEY
                );

                xhr.upload.onprogress = (event) => {
                    if (event.lengthComputable) {
                        const percent = Math.floor(
                            (event.loaded / event.total) * 100
                        );
                        setUploadProgress(percent);
                    }
                };

                xhr.onload = () => {
                    setUploading(false);

                    if (xhr.status === 200) {

                        // Save to form
                        setForm(p => ({
                           ...p,
                            introBunnyVideoId: videoId,

                            introVideoUrl:
                                `https://iframe.mediadelivery.net/play/${import.meta.env.VITE_BUNNY_LIBRARY_ID}/${videoId}`
                        }));

                        alert("✅ Video Uploaded Successfully!");
                        resolve();

                    } else {
                        console.error("❌ Bunny error:", xhr.responseText);
                        reject(new Error(xhr.responseText));
                    }
                };

                xhr.onerror = () => {
                    setUploading(false);
                    reject(new Error("Network error during upload"));
                };

                xhr.send(file);
            });

        } catch (err) {

            setUploading(false);

            console.error("Upload failed:", err);

            alert(
                "Upload failed: " +
                (err.response?.data?.message || err.message)
            );
        }
    }

    // ================= CREATE =================
    async function createCourse(e) {
        e.preventDefault();
        if (!isValid) return;

        await api.post("/courses", form, {
            headers: { Authorization: "Bearer " + localStorage.getItem("token") },
        });

        resetForm();
        load();
    }

    // ================= EDIT =================
    function startEdit(c) {
        setEditing(c.id);

        setForm({
            title: c.title || "",
            description: c.description || "",
            price: c.price || "",
            oldPrice: c.oldPrice || "",
            thumbnail: c.thumbnail || "",

            introBunnyVideoId: c.introBunnyVideoId || "",
            introVideoUrl: c.introVideoUrl || "",
        });
    }

    async function saveEdit(e) {
        e.preventDefault();
        if (!isValid) return;

        await api.put(`/courses/${editing}`, form, {
            headers: { Authorization: "Bearer " + localStorage.getItem("token") },
        });

        resetForm();
        load();
    }

    async function removeCourse(id) {
        if (!window.confirm("Delete this course?")) return;

        await api.delete(`/admin/courses/${id}`, {
            headers: { Authorization: "Bearer " + localStorage.getItem("token") },
        });

        load();
    }

    function resetForm() {
        setEditing(null);

        setForm({
            title: "",
            description: "",
            price: "",
            oldPrice: "",
            thumbnail: "",

            introBunnyVideoId: "",
            introVideoUrl: "",
        });

        setErrors({});
        setOverviewFile(null);
        setUploadProgress(0);
    }

    // ================= UI =================
    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-indigo-950">

            {/* Main Content */}
            <div className="max-w-[1800px] mx-auto px-8 py-8">
                <div className="grid grid-cols-12 gap-8">

                    {/* ================= LEFT : COURSE LIST ================= */}
                    <div className="col-span-7">

                        <div className="flex items-center justify-between mb-6">
                            <h3 className="text-xl font-bold text-white flex items-center gap-2">
                                <div className="w-1 h-6 bg-gradient-to-b from-indigo-500 to-purple-600 rounded-full"></div>
                                All Courses
                            </h3>
                            <div className="px-3 py-1.5 bg-slate-800/50 border border-slate-700/50 rounded-lg">
                                <span className="text-slate-300 text-sm font-medium">{courses.length} courses</span>
                            </div>
                        </div>

                        <div className="space-y-4">
                            {courses.map(c => (
                                <div
                                    key={c.id}
                                    className="bg-slate-900/50 backdrop-blur-sm border border-slate-800/50 rounded-xl overflow-hidden hover:border-indigo-500/30 hover:shadow-xl hover:shadow-indigo-500/5 transition-all duration-300 group"
                                >
                                    <div className="flex gap-4 p-4">

                                        {/* Thumbnail */}
                                        <div className="w-32 h-24 bg-slate-800/50 rounded-lg overflow-hidden flex-shrink-0 relative group-hover:ring-2 group-hover:ring-indigo-500/30 transition-all">
                                            {c.thumbnail? (
                                                <img
                                                    src={import.meta.env.VITE_API_URL.replace("/api", "") + c.thumbnail}
                                                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                                                    alt={c.title}
                                                />
                                            ) : (
                                                <div className="w-full h-full flex items-center justify-center">
                                                    <svg className="w-10 h-10 text-slate-700" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                                    </svg>
                                                </div>
                                            )}

                                            {/* Video Badge */}
                                            {c.introBunnyVideoId && (
                                                <div className="absolute top-1.5 left-1.5 bg-gradient-to-r from-green-500 to-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shadow-lg">
                                                    <svg className="w-2.5 h-2.5" fill="currentColor" viewBox="0 0 20 20">
                                                        <path d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" />
                                                    </svg>
                                                    VIDEO
                                                </div>
                                            )}
                                        </div>

                                        {/* Content */}
                                        <div className="flex-1 flex flex-col justify-between min-w-0">

                                            <div>
                                                <h4 className="font-bold text-white text-lg mb-1 truncate group-hover:text-indigo-400 transition-colors">
                                                    {c.title}
                                                </h4>
                                                <p className="text-slate-400 text-sm line-clamp-2 leading-relaxed">
                                                    {c.description}
                                                </p>
                                            </div>

                                            <div className="flex items-center justify-between mt-3">

                                                <div className="flex items-baseline gap-2">
                                                    <span className="text-2xl font-bold bg-gradient-to-r from-emerald-400 to-green-400 bg-clip-text text-transparent">
                                                        ₹{c.price}
                                                    </span>
                                                    {c.oldPrice && (
                                                        <>
                                                            <span className="text-slate-500 line-through text-sm">₹{c.oldPrice}</span>
                                                            <span className="text-xs font-semibold text-green-400 bg-green-400/10 px-2 py-0.5 rounded-full">
                                                                {Math.round((1 - c.price / c.oldPrice) * 100)}% OFF
                                                            </span>
                                                        </>
                                                    )}
                                                </div>

                                                <div className="flex gap-2 text-white"> {/* Added text-white here for the SVG buttons */}
                                                    <a
                                                        href={`/admin/course/${c.id}`}
                                                        className="px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-500 hover:from-indigo-700 hover:to-indigo-600 rounded-lg text-sm font-medium transition-all shadow-lg shadow-indigo-500/20 hover:shadow-indigo-500/40"
                                                    >
                                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L6.828 19H3v-3.586l1.414-1.414z" /> </svg>
                                                    </a>

                                                    {/* NEW BUTTON: Manage Curriculum */}
                                                  

                                                    <button
                                                        onClick={() => startEdit(c)}
                                                        className="px-4 py-2 bg-slate-800 hover:bg-slate-700 border border-slate-700 hover:border-slate-600 rounded-lg text-sm font-medium transition-all"
                                                    >
                                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                                        </svg>
                                                    </button>

                                                    <button
                                                        onClick={() => removeCourse(c.id)}
                                                        className="px-4 py-2 bg-red-900/50 hover:bg-red-900 border border-red-800 hover:border-red-700 rounded-lg text-sm font-medium transition-all"
                                                    >
                                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">

                                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.143A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.857L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                                                        </svg>
                                                    </button>
                                                </div>

                                            </div>

                                        </div>

                                    </div>
                                </div>
                            ))}
                        </div>

                        {courses.length === 0 && (
                            <div className="bg-slate-900/30 backdrop-blur-sm border border-slate-800/50 border-dashed rounded-2xl p-20 text-center">
                                <div className="w-20 h-20 bg-gradient-to-br from-slate-800 to-slate-900 rounded-2xl flex items-center justify-center mx-auto mb-6 shadow-xl">
                                    <svg className="w-10 h-10 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                                    </svg>
                                </div>
                                <h3 className="text-slate-400 text-xl font-semibold mb-2">No courses yet</h3>
                                <p className="text-slate-600 text-sm">Create your first course to get started</p>
                            </div>
                        )}

                    </div>

                    {/* ================= RIGHT : FORM ================= */}
                    <div className="col-span-5 right-0 overflow-y-auto">

                        <div className="bg-slate-900/50 backdrop-blur-sm border border-slate-800/50 overflow-hidden sticky top-24 shadow-2xl">

                            {/* Form Header */}
                            <div className="bg-gradient-to-r from-indigo-600/20 via-purple-600/20 to-pink-600/20 border-b border-slate-800/50 p-6">
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                                        {editing? (
                                            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                            </svg>
                                        ) : (
                                            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                                            </svg>
                                        )}
                                    </div>
                                    <div>
                                        <h3 className="text-xl font-bold text-white">
                                            {editing? "Edit Course" : "Create Course"}
                                        </h3>
                                        <p className="text-slate-400 text-xs mt-0.5">
                                            {editing? "Update course details" : "Add new course to catalog"}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            <form onSubmit={editing? saveEdit : createCourse} className="p-6">

                                {/* Thumbnail Preview */}
                                {form.thumbnail && (
                                    <div className="mb-6 relative group">
                                        <img
                                            src={import.meta.env.VITE_API_URL.replace("/api", "") + form.thumbnail}
                                            className="w-full h-48 object-cover rounded-xl border border-slate-800/50 shadow-xl"
                                            alt="Course thumbnail"
                                        />
                                        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity">
                                            <div className="absolute bottom-3 right-3">
                                                <div className="px-3 py-1.5 bg-white/10 backdrop-blur-md rounded-lg text-xs text-white font-medium">
                                                    Thumbnail Preview
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {/* Title */}
                                <div className="mb-5">
                                    <label className="text-sm font-semibold text-slate-300 mb-2 flex items-center gap-2">
                                        <svg className="w-4 h-4 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                                        </svg>
                                        Course Title
                                    </label>
                                    <input
                                        className="w-full bg-slate-800/50 border border-slate-700/50 p-3.5 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all"
                                        placeholder="e.g., Complete Web Development"
                                        value={form.title}
                                        onChange={e => setForm({...form, title: e.target.value })}
                                    />
                                    {errors.title && (
                                        <p className="text-red-400 text-xs mt-1.5 flex items-center gap-1">
                                            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                            </svg>
                                            {errors.title}
                                        </p>
                                    )}
                                </div>

                                {/* Description */}
                                <div className="mb-5">
                                    <label className="text-sm font-semibold text-slate-300 mb-2 flex items-center gap-2">
                                        <svg className="w-4 h-4 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />
                                        </svg>
                                        Description
                                    </label>
                                    <textarea
                                        rows={4}
                                        className="w-full bg-slate-800/50 border border-slate-700/50 p-3.5 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all resize-none"
                                        placeholder="What will students learn..."
                                        value={form.description}
                                        onChange={e => setForm({...form, description: e.target.value })}
                                    />
                                    {errors.description && (
                                        <p className="text-red-400 text-xs mt-1.5 flex items-center gap-1">
                                            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                            </svg>
                                            {errors.description}
                                        </p>
                                    )}
                                </div>

                                {/* Price Row */}
                                <div className="grid grid-cols-2 gap-4 mb-5">
                                    <div>
                                        <label className="text-sm font-semibold text-slate-300 mb-2 flex items-center gap-2">
                                            <svg className="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3.895-3 2s1.343 2 3 2 3.895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                                            </svg>
                                            Selling Price
                                        </label>
                                        <div className="relative">
                                            <span className="absolute left-4 top-3.5 text-slate-400 font-semibold">₹</span>
                                            <input
                                                className="w-full bg-slate-800/50 border border-slate-700/50 p-3.5 pl-9 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 transition-all"
                                                placeholder="999"
                                                value={form.price}
                                                onChange={e => setForm({...form, price: e.target.value })}
                                            />
                                        </div>
                                        {errors.price && (
                                            <p className="text-red-400 text-xs mt-1.5">{errors.price}</p>
                                        )}
                                    </div>

                                    <div>
                                        <label className="text-sm font-semibold text-slate-300 mb-2 flex items-center gap-2">
                                            <svg className="w-4 h-4 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z" />
                                            </svg>
                                            Old Price
                                        </label>
                                        <div className="relative">
                                            <span className="absolute left-4 top-3.5 text-slate-400 font-semibold">₹</span>
                                            <input
                                                className="w-full bg-slate-800/50 border border-slate-700/50 p-3.5 pl-9 rounded-xl text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:border-indigo-500/50 transition-all"
                                                placeholder="1999"
                                                value={form.oldPrice}
                                                onChange={e => setForm({...form, oldPrice: e.target.value })}
                                            />
                                        </div>
                                        {errors.oldPrice && (
                                            <p className="text-red-400 text-xs mt-1.5">{errors.oldPrice}</p>
                                        )}
                                    </div>
                                </div>

                                {/* Thumbnail Upload */}
                                <div className="mb-5">
                                    <label className="text-sm font-semibold text-slate-300 mb-2 flex items-center gap-2">
                                        <svg className="w-4 h-4 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                        </svg>
                                        Thumbnail
                                    </label>
                                    <input
                                        type="file"
                                        accept="image/*"
                                        className="w-full bg-slate-800/50 border border-slate-700/50 p-3 rounded-xl text-slate-300 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 file:cursor-pointer transition-all"
                                        onChange={e => uploadThumbnail(e.target.files[0])}
                                    />
                                    {errors.thumbnail &&!form.thumbnail && (
                                        <p className="text-red-400 text-xs mt-1.5 flex items-center gap-1">
                                            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                                            </svg>
                                            {errors.thumbnail}
                                        </p>
                                    )}
                                </div>

                                {/* Overview Video */}
                                {/* Video Upload Section */}
                                <div className="mb-5 p-4 bg-slate-800/30 rounded-xl border border-slate-700/50">
                                    <label className="text-sm font-semibold text-slate-300 mb-2 block">
                                        Intro Video (Overview)
                                    </label>

                                    <input
                                        type="file"
                                        accept="video/*"
                                        onChange={(e) => setOverviewFile(e.target.files[0])}
                                        className="block w-full text-sm text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-indigo-600 file:text-white hover:file:bg-indigo-700 mb-3"
                                    />

                                    {uploading? (
                                        <div className="w-full bg-slate-700 rounded-full h-2.5 mb-2">
                                            <div
                                                className="bg-indigo-500 h-2.5 rounded-full transition-all duration-300"
                                                style={{ width: `${uploadProgress}%` }}
                                            ></div>
                                            <p className="text-[10px] text-indigo-300 mt-1">Uploading: {uploadProgress}%</p>
                                        </div>
                                    ) : (
                                        <button
                                            type="button"
                                            onClick={() => simpleUpload(overviewFile)} // You can choose between simpleUpload or uploadOverviewVideo
                                            className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-white text-xs font-bold rounded-lg transition-all"
                                        >
                                            {form.introBunnyVideoId? "Replace Video" : "Upload Video"}
                                        </button>
                                    )}
                                </div>

                                {/* Submit Button */}
                                <button
                                    disabled={!isValid}
                                    className={`w-full py-4 rounded-xl font-bold text-base transition-all ${isValid
                                       ? "bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 hover:from-indigo-700 hover:via-purple-700 hover:to-pink-700 shadow-2xl shadow-indigo-500/30 hover:shadow-indigo-500/50 text-white"
                                        : "bg-slate-800/50 opacity-60 cursor-not-allowed text-slate-500"
                                        }`}
                                >
                                    {editing? "💾 Save Changes" : "✨ Create Course"}
                                </button>

                                {editing && (
                                    <button
                                        type="button"
                                        onClick={resetForm}
                                        className="w-full mt-3 py-3 bg-slate-800/50 hover:bg-slate-800 border border-slate-700/50 rounded-xl font-medium transition-all text-white" // Added text-white
                                    >
                                        Cancel
                                    </button>
                                )}

                            </form>

                        </div>
                    </div>

                </div>
            </div>

            {/* Bottom Spacing */}
            <div className="h-16"></div>

        </div >
    );
}