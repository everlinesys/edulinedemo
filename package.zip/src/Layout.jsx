import { getUser } from "./auth";
import { useBranding } from "./useBranding";

export default function Layout({ children }) {
  const user = getUser();
  const brand = useBranding();

  const theme = brand.theme || {};
  const text = theme.text || {};
  const shape = theme.shape || {};
  const layout = theme.layout || {};
  const button = theme.button || {};

  function logout() {
    localStorage.removeItem("token");
    window.location = "/";
  }

  return (
    <div
      className={`min-h-screen flex flex-col min-w-full w-[100vw] font-sans ${layout.page || "bg-slate-900 text-white"} gap-0`}
      style={{ "--color-primary": brand.colors.primary }}
    >

      {/* HEADER */}
      <header className={`sticky top-0 z-50 w-full ${layout.header || layout.panel}`}>
        <div className="w-full px-4 md:px-8 h-16 flex items-center justify-between">

          {/* LOGO */}
          <a href={user ? "" : "/"} className="flex items-center gap-3 active:scale-95">

            <span
              className={text.title || "font-bold text-white"}
              style={{ color: "var(--color-primary)" }}
            >
              {brand.siteName}
            </span>

          </a>

          {/* NAV */}
          <nav className="flex items-center gap-6">

            <div className="hidden md:flex items-center gap-6 text-sm font-bold">

              {user && (
                <a
                  href={user.role === "ADMIN" ? "/admin" : "/dashboard"}
                  className={`${text.body || "text-white/70"} hover:opacity-100 transition`}
                >
                  {user.role === "ADMIN" ? "Admin Panel" : "My Learning"}
                </a>
              )}

            </div>

            {/* ACTIONS */}
            <div className="flex items-center gap-2 pl-6 border-l border-white/10">

              {!user ? (
                <>
                  <a
                    href="/login"
                    className={`text-sm font-bold ${text.body || "text-white/70"} hover:opacity-100`}
                  >
                    Log in
                  </a>

                  <a
                    href="/register"
                    className={` text-white"} ${shape.buttonRadius || "rounded-md"} text-sm font-black px-4 py-2`}
                  >
                    Join Now
                  </a>
                </>
              ) : (
                <div className="flex items-center gap-4">

                  <div className="hidden sm:block text-right">
                    <p className={`text-[10px] uppercase ${text.label || "text-white/50"}`}>
                      Logged in as
                    </p>
                    <p className={`text-xs font-bold ${text.body || "text-white/80"}`}>
                      {user.name || "User"}
                    </p>
                  </div>

                  <button
                    onClick={logout}
                    className={`${button.danger || "bg-red-600 text-white"} ${shape.buttonRadius || "rounded-md"} px-4 py-2 text-xs font-bold`}
                  >
                    Logout
                  </button>

                </div>
              )}

            </div>

          </nav>

        </div>
      </header>

      {/* MAIN */}
      <main className="w-full flex-1 animate-in fade-in duration-700">
        {children}
      </main>

      {/* FOOTER */}
      <footer className={`w-full ${layout.footer || layout.panel}`}>
        <div className="w-full px-4 md:px-8 py-8 flex flex-col md:flex-row items-center justify-between gap-4">

          <div className="flex items-center gap-2">
            {brand.logo && <img src={brand.logo} className="h-5 opacity-80" alt="" />}
            <span className={text.title || "font-bold text-white"}>
              {brand.siteName}
            </span>
          </div>

          <p className={`text-xs uppercase tracking-widest ${text.label || "text-white/60"}`}>
            © {new Date().getFullYear()} — Made with Passion for Learners
          </p>

          <div className={`flex gap-6 text-[10px] uppercase tracking-widest ${text.label || "text-white/60"}`}>
            <a href="#" className="hover:opacity-100">Privacy</a>
            <a href="#" className="hover:opacity-100">Terms</a>
            <a href="#" className="hover:opacity-100">Support</a>
            <a href="https://everlinesystems.in" className="hover:opacity-100">Site By</a>
          </div>

        </div>
      </footer>

    </div>
  );
}
