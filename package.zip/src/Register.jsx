import { useState } from "react";
import api from "./api";
import { useBranding } from "./useBranding";

export default function Register() {
  const [form, setForm] = useState({ name: "", email: "", password: "" });

  const brand = useBranding();
  const theme = brand.theme;

  async function submit(e) {
    e.preventDefault();

    try {
      // 1. Create account
      await api.post("/auth/register", form);

      // 2. Immediately login with same credentials
      const res = await api.post("/auth/login", {
        email: form.email,
        password: form.password,
      });

      // 3. EXACT same logic as Login.jsx
      localStorage.setItem("token", res.data.token);

      const user = res.data.user;
      console.log("AUTO LOGIN AFTER REGISTER:", res.data);

      // 4. SAME redirect logic
      if (user.role === "ADMIN") {
        window.location = "/admin";
      } else {
        window.location = "/dashboard";
      }

    } catch (e) {
      alert(e.response?.data?.message || "Error creating account");
    }
  }



  return (
    <section
      className={`
        min-h-screen flex items-center justify-center
        ${theme.layout.container}
      `}
      style={{ "--color-primary": brand.colors.primary }}
    >
      {/* CARD */}
      <div
        className={`
          w-full max-w-md
          p-6 md:p-8 space-y-5
          shadow-2xl
          ${theme.layout.panel}
          ${theme.shape.radius}
        `}
      >
        {/* TITLE */}
        <h2 className={`text-2xl ${theme.text.title}`}>
          Create Account
        </h2>

        {/* FORM */}
        <form onSubmit={submit} className="space-y-4">

          {/* NAME */}
          <input
            className={`
              w-full px-3 py-2 text-sm
              ${theme.input.base}
              ${theme.shape.inputRadius}
            `}
            placeholder="Full name"
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
          />

          {/* EMAIL */}
          <input
            className={`
              w-full px-3 py-2 text-sm
              ${theme.input.base}
              ${theme.shape.inputRadius}
            `}
            placeholder="Email"
            value={form.email}
            onChange={e => setForm({ ...form, email: e.target.value })}
          />

          {/* PASSWORD */}
          <input
            type="password"
            className={`
              w-full px-3 py-2 text-sm
              ${theme.input.base}
              ${theme.shape.inputRadius}
            `}
            placeholder="Password"
            value={form.password}
            onChange={e => setForm({ ...form, password: e.target.value })}
          />

          {/* SUBMIT */}
          <button
            className={`
              w-full py-2.5 text-sm font-bold transition-all
              ${theme.button.primary}
              ${theme.shape.buttonRadius}
            `}
          >
            Sign up
          </button>

        </form>

        {/* LOGIN LINK */}
        <div className={`text-sm ${theme.text.body}`}>
          Already have an account?{" "}
          <a
            href="/login"
            className="underline font-semibold"
            style={{ color: "var(--color-primary)" }}
          >
            Log in
          </a>
        </div>

      </div>
    </section>
  );
}
