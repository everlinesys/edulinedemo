import { useEffect, useState } from "react";
import api from "./api";

export default function AdminStudents() {
  const [users, setUsers] = useState([]);
  const [courses, setCourses] = useState([]);
  const [expanded, setExpanded] = useState({});
  const [query, setQuery] = useState("");
  const [activeTab, setActiveTab] = useState("students");

  // Add User Modal
  const [showAdd, setShowAdd] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  // Assign course modal
  const [assigningUser, setAssigningUser] = useState(null);
  const [selectedCourse, setSelectedCourse] = useState("");

  // UI Action Modal (Replacing Alerts/Confirms)
  const [uiModal, setUiModal] = useState({ show: false, title: "", msg: "", onConfirm: null });

  useEffect(() => {
    load();
  }, []);

  async function load() {
    const u = await api.get("/students");
    const c = await api.get("/courses");
    setUsers(u.data || []);
    setCourses(c.data || []);
  }

  function toggle(id) {
    setExpanded((p) => ({ ...p, [id]: !p[id] }));
  }

  /* ================= HELPERS (MODAL ALERTS) ================= */
  const showAlert = (title, msg) => setUiModal({ show: true, title, msg, onConfirm: null });
  const showConfirm = (title, msg, fn) => setUiModal({ show: true, title, msg, onConfirm: fn });

  /* ================= CREATE USER ================= */

  async function addUser(e) {
    e.preventDefault();
    if (!email) return showAlert("Required", "Email is required to create a user.");

    await api.post("/admin/students", { name, email });

    setName("");
    setEmail("");
    setShowAdd(false);
    load();
    showAlert("Success", "User has been created successfully.");
  }

  /* ================= ACTIONS ================= */

  async function resetPassword(userId) {
    showConfirm("Reset Password", "Are you sure? A new password will be emailed to the user.", async () => {
      await api.post(`/admin/students/${userId}/reset-password`);
      setUiModal({ show: false });
      setTimeout(() => showAlert("Sent", "New password sent to user"), 300);
    });
  }

  async function toggleBlock(user) {
    const label = user.blocked ? "Unblock" : "Block";
    showConfirm(`${label} User`, `Are you sure you want to ${label.toLowerCase()} this user?`, async () => {
      await api.post(`/admin/students/${user.id}/block`);
      load();
      setUiModal({ show: false });
    });
  }

  async function assignCourse() {
    if (!assigningUser || !selectedCourse) return;

    await api.post(`/admin/students/${assigningUser.id}/assign-course`, {
      courseId: Number(selectedCourse),
    });

    setAssigningUser(null);
    setSelectedCourse("");
    load();
    showAlert("Assigned", "Course access has been granted.");
  }

  /* ================= FILTERING ================= */

  const filtered = users.filter(
    (u) =>
      u.email?.toLowerCase().includes(query.toLowerCase()) ||
      u.name?.toLowerCase().includes(query.toLowerCase())
  );

  const students = filtered.filter((u) => u.purchases?.length > 0);
  const visitors = filtered.filter((u) => !u.purchases || u.purchases.length === 0);

  const list = activeTab === "students" ? students : visitors;

  /* ================= UI ================= */

  return (
    <div className="min-h-screen bg-[#f8fafc] p-4 md:p-10 space-y-6 text-slate-900">
      {/* HEADER */}
      <div className="flex justify-between items-center max-w-6xl mx-auto">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900">User Management</h2>
          <p className="text-[12px] text-slate-500 font-medium">Review student activity and manage course access.</p>
        </div>

        <button
          onClick={() => setShowAdd(true)}
          className="bg-slate-900 hover:bg-slate-800 text-white px-4 py-2 rounded-lg text-[12px] font-bold transition-all shadow-sm active:scale-95"
        >
          + Create User
        </button>
      </div>

      <div className="max-w-6xl mx-auto space-y-4">
        {/* TABS & SEARCH */}
        <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
          <div className="flex p-1 bg-slate-200/50 rounded-xl">
            <button
              onClick={() => setActiveTab("students")}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === "students" ? "bg-white text-slate-400 shadow-sm" : "text-slate-200"
              }`}
            >
              Students ({students.length})
            </button>
            <button
              onClick={() => setActiveTab("visitors")}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeTab === "visitors" ? "bg-white text-slate-400 shadow-sm" : "text-slate-200"
              }`}
            >
              Visitors ({visitors.length})
            </button>
          </div>

          <input
            className="w-full max-w-xs bg-white border border-slate-200 focus:border-slate-400 outline-none px-3 py-2 rounded-lg text-xs transition-all"
            placeholder="Search by name or email..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>

        {/* LIST */}
        <div className="space-y-2">
          {list.map((u) => (
            <div key={u.id} className="bg-white border border-slate-200 rounded-xl overflow-hidden transition-all hover:border-slate-300">
              <button
                onClick={() => toggle(u.id)}
                className="w-full flex justify-between items-center px-5 py-4 hover:bg-slate-50/50 transition-colors"
              >
                <div className="flex items-center gap-3 text-left">
                  <div className="h-8 w-8 rounded-lg bg-slate-100 flex items-center justify-center text-slate-500 font-bold text-[10px] uppercase">
                    {(u.name || u.email).substring(0, 2)}
                  </div>
                  <div>
                    <div className="font-bold text-slate-300 text-sm">{u.name || "Unnamed User"}</div>
                    <div className="text-[11px] text-slate-400 font-medium">{u.email}</div>
                  </div>
                </div>
                <span className={`text-slate-300 transition-transform ${expanded[u.id] ? 'rotate-180' : ''}`}>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 9l-7 7-7-7" /></svg>
                </span>
              </button>

              {expanded[u.id] && (
                <div className="border-t border-slate-100 bg-slate-50/30 p-5 space-y-6 animate-in slide-in-from-top-1">
                  {/* ACTIONS */}
                  <div className="flex flex-wrap gap-2">
                    <button onClick={() => resetPassword(u.id)} className="px-3 py-1.5 text-[11px] font-bold rounded-md bg-white border border-slate-200 text-slate-500 hover:bg-slate-50">
                      Reset Password
                    </button>
                    <button onClick={() => setAssigningUser(u)} className="px-3 py-1.5 text-[11px] font-bold rounded-md bg-indigo-50 text-indigo-700 border border-indigo-100 hover:bg-indigo-100">
                      Assign Course
                    </button>
                    <button
                      onClick={() => toggleBlock(u)}
                      className={`px-3 py-1.5 text-[11px] font-bold rounded-md border ${
                        u.blocked ? "bg-emerald-50 text-emerald-700 border-emerald-100" : "bg-rose-50 text-rose-700 border-rose-100"
                      }`}
                    >
                      {u.blocked ? "Unblock User" : "Block User"}
                    </button>
                  </div>

                  {/* PURCHASES */}
                  <div className="space-y-3">
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-400">Curriculum Tracking</h4>
                    {u.purchases?.length === 0 ? (
                      <div className="text-[12px] text-slate-400 italic">No active enrollments found.</div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {u.purchases.map((p) => (
                          <div key={p.id} className="bg-white border border-slate-200 p-4 rounded-lg">
                            <div className="flex justify-between items-start mb-3">
                              <span className="font-bold text-slate-800 text-[13px]">{p.course?.title}</span>
                              <span className={`text-[9px] px-1.5 py-0.5 rounded font-black uppercase ${p.status === 'active' ? 'bg-indigo-100 text-indigo-700' : 'bg-slate-100 text-slate-500'}`}>
                                {p.status}
                              </span>
                            </div>
                            <div className="space-y-2">
                              <div className="flex justify-between text-[10px] font-bold text-slate-400 uppercase">
                                <span>Progress</span>
                                <span className="text-slate-900">{p.progressPercent ?? 0}%</span>
                              </div>
                              <div className="w-full bg-slate-100 h-1 rounded-full">
                                <div className="bg-slate-900 h-full rounded-full" style={{ width: `${p.progressPercent ?? 0}%` }} />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* MODALS */}
      {(showAdd || assigningUser) && (
        <div className="fixed inset-0 bg-slate-900/20 backdrop-blur-[2px] flex items-center justify-center z-50 p-6">
          <div className="bg-white border border-slate-200 w-full max-w-sm rounded-2xl p-8 shadow-xl animate-in fade-in zoom-in duration-200">
            {showAdd ? (
              <form onSubmit={addUser} className="space-y-4">
                <div className="space-y-1">
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">New Student Account</h3>
                  <p className="text-[11px] text-slate-500">Enter details to generate access credentials.</p>
                </div>
                <div className="space-y-3">
                  <input className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs outline-none focus:border-slate-400 transition-all" placeholder="Full Name (optional)" value={name} onChange={(e) => setName(e.target.value)} />
                  <input className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs outline-none focus:border-slate-400 transition-all" placeholder="Email Address" required value={email} onChange={(e) => setEmail(e.target.value)} />
                </div>
                <div className="flex gap-3 pt-2">
                  <button type="button" onClick={() => setShowAdd(false)} className="flex-1 text-xs font-bold text-slate-400 hover:text-slate-600 transition-colors">Discard</button>
                  <button type="submit" className="flex-[2] bg-slate-900 text-white py-2.5 rounded-lg text-xs font-bold shadow-sm active:scale-95">Create Account</button>
                </div>
              </form>
            ) : (
              <div className="space-y-4">
                <div className="space-y-1">
                  <h3 className="text-sm font-black text-slate-900 uppercase tracking-tight">Enroll Student</h3>
                  <p className="text-[11px] text-slate-500 truncate">Assigning to: {assigningUser.email}</p>
                </div>
                <select className="w-full bg-slate-50 border border-slate-200 px-3 py-2 rounded-lg text-xs outline-none focus:border-slate-400 appearance-none" value={selectedCourse} onChange={(e) => setSelectedCourse(e.target.value)}>
                  <option value="">Choose Course...</option>
                  {courses.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}
                </select>
                <div className="flex gap-3 pt-2">
                  <button onClick={() => setAssigningUser(null)} className="flex-1 text-xs font-bold text-slate-400 hover:text-slate-600 transition-colors">Cancel</button>
                  <button onClick={assignCourse} className="flex-[2] bg-indigo-600 text-white py-2.5 rounded-lg text-xs font-bold shadow-sm active:scale-95">Confirm Assignment</button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* UI MODAL (ALERTS REPLACEMENT) */}
      {uiModal.show && (
        <div className="fixed inset-0 bg-slate-900/10 backdrop-blur-[1px] flex items-center justify-center z-[100] p-6">
          <div className="bg-white border border-slate-200 w-full max-w-[280px] rounded-2xl p-6 text-center space-y-4 shadow-2xl animate-in fade-in zoom-in duration-150">
            <h3 className="text-[13px] font-black text-slate-900 uppercase tracking-tight">{uiModal.title}</h3>
            <p className="text-[11px] text-slate-500 leading-relaxed font-medium">{uiModal.msg}</p>
            <div className="flex gap-2">
              {uiModal.onConfirm ? (
                <>
                  <button onClick={() => setUiModal({ show: false })} className="flex-1 px-3 py-2 rounded-lg bg-slate-100 text-slate-600 font-bold text-[11px]">Cancel</button>
                  <button onClick={uiModal.onConfirm} className="flex-1 px-3 py-2 rounded-lg bg-slate-900 text-white font-bold text-[11px]">Confirm</button>
                </>
              ) : (
                <button onClick={() => setUiModal({ show: false })} className="w-full px-3 py-2 rounded-lg bg-slate-900 text-white font-bold text-[11px]">OK</button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}