import { useState, useEffect } from "react";
import api from "./api";
import { getUser } from "./auth";
import { useCourseData } from "./coursePlayer/useCourseData";

import CoursePlayer from "./coursePlayer/CoursePlayer"; // still used for tests container styling
import VideoPlayer from "./BunnyStream/VideoPlayer";

import SyllabusSidebar from "./coursePlayer/SyllabusSidebar";
import TestViewer from "./coursePlayer/TestViewer";

export default function Watch({ courseId }) {
  const user = getUser();
  const course = useCourseData(courseId);

  // ================= STATE =================
  const [currentTest, setCurrentTest] = useState(null);
  const [finalTest, setFinalTest] = useState(null);
  const [showFinalTest, setShowFinalTest] = useState(false);
  const [finalPassed, setFinalPassed] = useState(null); // null = loading
  const [downloading, setDownloading] = useState(false);

  const current = course.current;
  const isChapter = current?.chapter;

  // ================= DERIVED META =================
  const unit = isChapter
    ? course.units.find((u) => u.id === current.unitId)
    : null;

  const chaptersInUnit = unit ? course.chaptersByUnit[unit.id] || [] : [];

  const chapterIndex = isChapter
    ? chaptersInUnit.findIndex((c) => c.id === current.chapter.id) + 1
    : 0;

  // ================= FINAL TEST STATUS =================
  useEffect(() => {
    
    async function checkFinalStatus() {
      try {
        const res = await api.get(`/final-test/status/${courseId}`);
        setFinalPassed(res.data.passed);
      } catch {
        setFinalPassed(false);
      }
    }

    if (course.isCourseCompleted()) {
      checkFinalStatus();
    }
  }, [courseId, course.isCourseCompleted()]);

  useEffect(() => {
  if (!isChapter) return;

  const timer = setTimeout(() => {
    course.completeChapter(
      current.unitId,
      current.chapter.id
    );
  }, 30000); // 0.5 min watch assumption

  return () => clearTimeout(timer);
}, [current?.chapter?.id]);


  // ================= UNIT TEST =================
  function startUnitTest(test) {
    setCurrentTest(test);
  }

  function closeUnitTest() {
    setCurrentTest(null);
  }

  function handleUnitTestSubmit() {
    setCurrentTest(null);
  }

  // ================= FINAL TEST =================
  async function startFinalTest() {
    try {
      const res = await api.get(`/final-test/${courseId}`);
      setFinalTest(res.data);
      setShowFinalTest(true);
    } catch (err) {
      alert("Final test not available");
      console.error(err);
    }
  }

  async function handleFinalSubmit({ score }) {
    await api.post("/final-test/submit", {
      userId: user.id,
      courseId,
      score,
    });

    setFinalPassed(score >= 60);
    setShowFinalTest(false);
    setFinalTest(null);
  }

  // ================= CERTIFICATE =================
  async function downloadCertificate() {
    try {
      setDownloading(true);

      const res = await api.get(`/certificate/${courseId}`, {
        responseType: "blob",
      });

      const blob = new Blob([res.data], { type: "application/pdf" });
      const url = window.URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = `certificate-course-${courseId}.pdf`;
      a.click();

      window.URL.revokeObjectURL(url);
    } catch (err) {
      alert("Certificate not available");
      console.error(err);
    } finally {
      setDownloading(false);
    }
  }

  // ================= SAFETY CHECK =================
  if (isChapter && !current.chapter.bunnyVideoId) {
    return (
      <div className="p-12 text-center text-red-500">
        This chapter has no Bunny video attached.
      </div>
    );
  }

  // ================= UI =================
  return (
    <div className="min-h-screen bg-slate-50/50">
      <div className="grid lg:grid-cols-4 gap-0 lg:gap-8 p-0 lg:p-8 max-w-[1700px] mx-auto">

        {/* ================= LEFT: MAIN CONTENT ================= */}
        <div className="lg:col-span-3 space-y-6 px-4 lg:px-0 py-6 lg:py-0">

          {/* PLAYER / TEST CONTAINER */}
          <div className="relative group rounded-2xl overflow-hidden bg-slate-900 shadow-2xl transition-all duration-500">

            {/* ===== BUNNY PLAYER ===== */}
            {!currentTest && !showFinalTest && isChapter ? (
              <VideoPlayer
                videoId={current.chapter.bunnyVideoId}

                onEnded={() => {
                  setTimeout(() => {
                    course.completeChapter(
                      current.unitId,
                      current.chapter.id
                    );
                  }, 3000);
                }}


                poster={
                  current.chapter.thumbnail ||
                  current.chapter.poster ||
                  undefined
                }
              />
            ) : currentTest ? (

              <div className="p-4 lg:p-8 bg-white min-h-[500px] flex flex-col justify-center">
                <TestViewer
                  test={course.testsByUnit[currentTest.unitId]}
                  mode="unit"
                  onSubmit={handleUnitTestSubmit}
                  onCancel={closeUnitTest}
                />
              </div>

            ) : showFinalTest && finalTest ? (

              <div className="p-4 lg:p-8 bg-white min-h-[600px] flex flex-col justify-center">
                <TestViewer
                  test={finalTest}
                  mode="final"
                  onSubmit={handleFinalSubmit}
                  onCancel={() => {
                    setShowFinalTest(false);
                    setFinalTest(null);
                  }}
                />
              </div>

            ) : null}
          </div>

          {/* ===== CHAPTER META ===== */}
          {!currentTest && !showFinalTest && isChapter && unit && (
            <div className="bg-white rounded-2xl p-8 border border-slate-100 shadow-sm space-y-6">

              <div className="flex flex-wrap items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-slate-400">
                <span>{course.courseTitle}</span>
                <span>/</span>
                <span className="text-indigo-500">{unit.title}</span>
              </div>

              <div className="space-y-3">
                <div className="flex items-center gap-4">
                  <div className="px-3 py-1 bg-indigo-50 text-indigo-600 rounded-full text-[11px] font-black uppercase">
                    Chapter {chapterIndex} of {chaptersInUnit.length}
                  </div>
                </div>

                <h1 className="text-3xl font-black text-slate-900">
                  {current.chapter.title}
                </h1>

                <p className="text-slate-500 text-lg">
                  {current.chapter.description}
                </p>
              </div>

              <div className="pt-4 flex items-center gap-3 border-t border-slate-50">
                <div
                  className={`w-2 h-2 rounded-full ${course.isCompleted(current.chapter.id)
                      ? "bg-emerald-500"
                      : "bg-amber-500 animate-pulse"
                    }`}
                />

                <span className="text-xs font-bold text-slate-400 uppercase">
                  {course.isCompleted(current.chapter.id)
                    ? "Completed"
                    : "Watching Now"}
                </span>
              </div>
            </div>
          )}

          {/* ===== FINAL TEST CTA ===== */}
          {course.isCourseCompleted() &&
            finalPassed === false &&
            !showFinalTest && (
              <div className="bg-indigo-900 rounded-2xl p-8 text-white flex flex-col md:flex-row items-center justify-between gap-6">

                <div>
                  <h3 className="text-2xl font-black">
                    Earn Your Certificate
                  </h3>

                  <p className="text-indigo-200 text-sm">
                    You've watched all videos. Complete final assessment.
                  </p>
                </div>

                <button
                  onClick={startFinalTest}
                  className="px-10 py-4 bg-white text-indigo-900 rounded-xl font-black"
                >
                  Start Final Exam
                </button>
              </div>
            )}

          {/* ===== CERTIFICATE ===== */}
          {finalPassed && (
            <div className="bg-emerald-600 rounded-2xl p-8 text-white flex flex-col md:flex-row items-center justify-between gap-6">

              <div>
                <h3 className="text-2xl font-black">
                  Congratulations!
                </h3>
              </div>

              <button
                onClick={downloadCertificate}
                disabled={downloading}
                className="px-10 py-4 bg-white text-emerald-700 rounded-xl"
              >
                {downloading
                  ? "Generating PDF..."
                  : "Download Certificate"}
              </button>
            </div>
          )}
        </div>

        {/* ================= SIDEBAR ================= */}
        <div className="lg:sticky lg:top-8">
          <SyllabusSidebar
            units={course.units}
            chaptersByUnit={course.chaptersByUnit}
            testsByUnit={course.testsByUnit}
            current={course.current}
            openUnitId={course.openUnitId}
            setOpenUnitId={course.setOpenUnitId}
            setCurrent={course.setCurrent}
            isCompleted={course.isCompleted}
            isUnitUnlocked={course.isUnitUnlocked}
            isChapterUnlocked={course.isChapterUnlocked}
            isUnitCompleted={course.isUnitCompleted}
            onStartTest={startUnitTest}
          />
        </div>
      </div>
    </div>
  );
}
