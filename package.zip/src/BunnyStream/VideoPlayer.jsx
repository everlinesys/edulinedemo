export default function VideoPlayer({ videoId }) {
  if (!videoId) return null;

  const src = `https://iframe.mediadelivery.net/play/${
    import.meta.env.VITE_BUNNY_LIBRARY_ID
  }/${videoId}`;

  return (
    <div className="w-full aspect-video relative bg-black rounded-xl overflow-hidden">
      <iframe
        src={src}
        className="absolute inset-0 w-full h-full"
        allow="
          accelerometer;
          autoplay;
          clipboard-write;
          encrypted-media;
          gyroscope;
          picture-in-picture;
          fullscreen
        "
        allowFullScreen
        style={{ border: 0 }}
      />
    </div>
  );
}
