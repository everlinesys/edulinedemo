import { useEffect, useState } from "react";
import api from "./api";

export default function CoursePage({ id }) {
  const [course, setCourse] = useState(null);
  const [chapters, setChapters] = useState([]);
  const [current, setCurrent] = useState(null);

  useEffect(() => {
    async function load() {
      const c = await api.get(`/courses/${id}`);
      setCourse(c.data);

      const ch = await api.get(`/chapters/${id}`);
      setChapters(ch.data);

      if (ch.data.length) setCurrent(ch.data[0]);
    }

    load();
  }, [id]);

  return (
    <div className="grid md:grid-cols-3 gap-4">
      <div className="md:col-span-2">
        {current && (
          <div className="space-y-2">
            <h2 className="text-xl font-bold">{current.title}</h2>

            <iframe
              src={current.videoUrl}
              className="w-full aspect-video rounded"
              allowFullScreen
            />
          </div>
        )}
      </div>

      <div className="space-y-2">
        <h3 className="font-bold">Chapters</h3>

        {chapters.map((c) => (
          <div
            key={c.id}
            className={`p-2 rounded cursor-pointer ${
              current?.id === c.id ? "bg-indigo-100" : "bg-white"
            }`}
            onClick={() => setCurrent(c)}
          >
            #{c.order} — {c.title}
          </div>
        ))}
      </div>
    </div>
  );
}
